/* 전화예약/취소 — 설명회별 예약 현황 + 수동예약 등록 + QR/문자 상세 */
function PhoneScreen({ store }) {
  const { Button, Input, Select, Tag, Card, Badge, Dialog, Toast, Tabs, Radio } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { sessions, students, reservations, addReservation, cancelReservation, moveReservation, reissueCode } = store;

  const [sessionId, setSessionId] = React.useState(sessions[0]?.id);
  const [chFilter, setChFilter] = React.useState('전체');
  const [selectedId, setSelectedId] = React.useState(null);
  const [cancelTarget, setCancelTarget] = React.useState(null);
  const [manualOpen, setManualOpen] = React.useState(false);
  const [moveOpen, setMoveOpen] = React.useState(false);
  const [moveTo, setMoveTo] = React.useState(null);
  const [toast, setToast] = React.useState(null);

  const seatsUsed = (sid) => reservations.filter((r) => r.sessionId === sid && r.status !== 'cancelled').length;

  const session = sessions.find((s) => s.id === sessionId);
  const rs = reservations.filter((r) => r.sessionId === sessionId);
  const phoneRs = rs.filter((r) => r.channel === 'phone' && r.status !== 'cancelled');
  const entered = rs.filter((r) => r.status === 'entered');
  const unchecked = rs.filter((r) => r.status === 'reserved');

  const list = rs.filter((r) => {
    if (chFilter === '전화') return r.channel === 'phone';
    if (chFilter === '취소됨') return r.status === 'cancelled';
    if (chFilter === '미체크') return r.status === 'reserved';
    return true;
  });
  const selected = reservations.find((r) => r.id === selectedId);

  const flash = (m) => { setToast(m); setTimeout(() => setToast(null), 3000); };
  const doCancel = () => { cancelReservation(cancelTarget.id); setCancelTarget(null); flash('예약이 취소되었어요 — 취소 안내 문자를 발송했어요'); };
  const onManualDone = (r) => { setManualOpen(false); setSelectedId(r.id); flash('예약이 등록됐어요 — QR과 문자를 확인하세요'); };
  const doReissue = () => { reissueCode(selected.id); flash(`QR을 재발급했어요 — 새 QR을 ${selected.phone}로 재발송했어요`); };
  const doMove = () => { const dest = sessions.find((s) => s.id === moveTo); moveReservation(selected.id, moveTo); setMoveOpen(false); setMoveTo(null); flash(`${dest.title} · ${dest.round}(으)로 변경했어요 — 변경 확정 문자를 발송했어요`); };

  return (
    <div data-screen-label="전화예약 관리">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div>
          <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)', marginBottom: 6 }}>PHONE RESERVATION</div>
          <h1 style={{ fontSize: 'var(--text-h1)', fontWeight: 800 }}>전화예약 관리</h1>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <Select options={sessions.map((s) => ({ label: `${s.title} · ${s.round}`, value: s.id }))} value={sessionId} onChange={(v) => { setSessionId(v); setSelectedId(null); }} style={{ width: 320 }} />
          <Button icon={<I.plus size={16} />} onClick={() => setManualOpen(true)}>수동예약 등록</Button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginTop: 20 }}>
        <StatCard label="전화예약 인원" value={phoneRs.length} suffix="건" tone="brand" icon={<I.phone size={15} />} delay={0} onClick={() => setChFilter('전화')} active={chFilter === '전화'} />
        <StatCard label="입장 완료" value={entered.length} suffix="명" tone="success" icon={<I.check size={15} />} delay={60} onClick={() => setChFilter('전체')} />
        <StatCard label="미체크" value={unchecked.length} suffix="명" tone="accent" icon={<I.clock size={15} />} delay={120} onClick={() => setChFilter('미체크')} active={chFilter === '미체크'} />
        <StatCard label="취소" value={rs.filter((r) => r.status === 'cancelled').length} suffix="건" tone="danger" icon={<I.x size={15} />} delay={180} onClick={() => setChFilter('취소됨')} active={chFilter === '취소됨'} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 360px' : '1fr', gap: 14, marginTop: 14, alignItems: 'start', transition: 'grid-template-columns var(--dur-base) var(--ease-smooth)' }}>
        <Card padding="0" style={{ overflow: 'hidden', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 200ms both' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '13px 20px', borderBottom: '1px solid var(--border-hairline)' }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>예약 목록</span>
            <span style={{ fontSize: 12.5, color: 'var(--text-faint)', fontFeatureSettings: '"tnum"' }}>{list.length}건</span>
            <span style={{ flex: 1 }}></span>
            {['전체', '전화', '미체크', '취소됨'].map((f) => <Tag key={f} selected={chFilter === f} onClick={() => setChFilter(f)} style={{ height: 30 }}>{f}</Tag>)}
          </div>
          {list.map((r, i) => (
            <div key={r.id} onClick={() => setSelectedId(r.id === selectedId ? null : r.id)}
              style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '13px 20px', borderTop: i > 0 ? '1px solid var(--border-hairline)' : 'none', cursor: 'pointer', background: selectedId === r.id ? 'var(--surface-brand-soft)' : 'var(--surface-card)', transition: 'background var(--dur-fast) var(--ease-out)', animation: `ds-fade-up var(--dur-base) var(--ease-out) ${Math.min(i, 10) * 35}ms both` }}>
              <span style={{ width: 150 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text-strong)', display: 'flex', gap: 6, alignItems: 'center' }}>{r.name} {!r.member && <Badge tone="accent" size="sm">비재원</Badge>} {r.groupId && <Badge tone="info" size="sm">형제</Badge>}</div>
                <div style={{ fontSize: 12, color: 'var(--text-faint)', display: 'flex', gap: 6, alignItems: 'center' }}>{r.school} · {r.grade}{r.history && r.history.length > 0 && <span style={{ color: 'var(--text-accent)', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 2 }}><I.calendar size={10} />회차변경</span>}</div>
              </span>
              <span style={{ fontSize: 13, color: 'var(--text-muted)', fontFeatureSettings: '"tnum"', width: 130 }}>{r.phone}</span>
              <Badge tone={r.channel === 'phone' ? 'info' : 'neutral'} size="sm">{nprChannelLabel[r.channel]}</Badge>
              {session.attendField && <span style={{ fontSize: 12.5, color: 'var(--text-muted)', fontFeatureSettings: '"tnum"' }}>{r.attendCount}명</span>}
              <span style={{ flex: 1 }}></span>
              <ResStatusBadge status={r.status} size="sm" />
              {r.status !== 'cancelled' && (
                <Button variant="ghost" size="sm" onClick={(e) => { e && e.stopPropagation && e.stopPropagation(); setCancelTarget(r); }} style={{ color: 'var(--status-danger)' }}>취소</Button>
              )}
            </div>
          ))}
          {list.length === 0 && <EmptyState>해당 조건의 예약이 없어요.</EmptyState>}
        </Card>

        {/* 예약 상세 — QR + 문자 발송 안내 */}
        {selected && (
          <Card padding="22px" style={{ position: 'sticky', top: 20, animation: 'ds-slide-in-right var(--dur-slow) var(--ease-spring) both' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)' }}>RESERVATION DETAIL</span>
              <button onClick={() => setSelectedId(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-faint)' }}><I.x size={16} /></button>
            </div>
            <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginTop: 14 }}>
              <QrBox code={selected.code} size={108} style={{ animation: 'ds-pop var(--dur-slow) var(--ease-spring) both' }} />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <KV k="예약자" v={`${selected.name} (${selected.grade})`} />
                <KV k="예약번호" v={<span style={{ fontFeatureSettings: '"tnum"', letterSpacing: '0.04em' }}>{selected.code}</span>} />
                <ResStatusBadge status={selected.status} />
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 16, paddingTop: 16, borderTop: '1px dashed var(--gray-3)' }}>
              <KV k="연락처" v={selected.phone} />
              <KV k="채널" v={nprChannelLabel[selected.channel] + '예약'} />
              <KV k="일시" v={`${session.date} ${session.time}`} />
              {session.attendField && <KV k="참석 인원" v={`${selected.attendCount}명`} />}
            </div>
            <div style={{ marginTop: 16, padding: '12px 14px', borderRadius: 'var(--radius-md)', background: 'var(--surface-brand-soft)', display: 'flex', gap: 10, alignItems: 'flex-start', fontSize: 12.5, color: 'var(--violet-800)', lineHeight: 1.5 }}>
              <I.message size={15} style={{ flexShrink: 0, marginTop: 1 }} />
              <span><b>{selected.phone}</b>로 QR이 담긴 예약 확정 문자를 발송했어요.</span>
            </div>
            {selected.codeHistory && selected.codeHistory.length > 0 && (
              <div style={{ marginTop: 8, fontSize: 11.5, color: 'var(--text-faint)', display: 'flex', gap: 5, alignItems: 'center' }}><I.refresh size={12} /> QR 재발급 {selected.codeHistory.length}회 · 이전 코드 무효</div>
            )}
            {selected.history && selected.history.length > 0 && (
              <div style={{ marginTop: 8, fontSize: 11.5, color: 'var(--text-faint)', display: 'flex', gap: 5, alignItems: 'center' }}><I.calendar size={12} /> 회차 변경 {selected.history.length}회</div>
            )}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 14 }}>
              <Button variant="secondary" size="sm" style={{ flex: '1 1 45%' }} icon={<I.send size={14} />} onClick={() => flash(`${selected.phone}로 문자를 재발송했어요`)}>문자 재발송</Button>
              {selected.status !== 'cancelled' && <Button variant="secondary" size="sm" style={{ flex: '1 1 45%' }} icon={<I.refresh size={14} />} onClick={doReissue}>QR 재발급</Button>}
              {selected.status === 'reserved' && <Button variant="secondary" size="sm" style={{ flex: '1 1 45%' }} icon={<I.calendar size={14} />} onClick={() => { setMoveTo(null); setMoveOpen(true); }}>예약 변경</Button>}
              {selected.status === 'reserved' && <Button variant="danger" size="sm" style={{ flex: '1 1 45%' }} onClick={() => setCancelTarget(selected)}>예약 취소</Button>}
            </div>
          </Card>
        )}
      </div>

      <ManualReserveDialog open={manualOpen} onClose={() => setManualOpen(false)} session={session} students={students} reservations={reservations} addReservation={addReservation} onDone={onManualDone} />

      {/* 예약 변경 — 회차 이동 (잔여석 표시, QR 유지) */}
      <Dialog open={moveOpen} onClose={() => setMoveOpen(false)} title="예약을 어디로 옮길까요?" width={460}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setMoveOpen(false)}>돌아가기</Button><Button disabled={!moveTo} onClick={doMove} icon={<I.check size={15} />}>이 설명회로 변경</Button></React.Fragment>}>
        {selected && <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.55 }}><b style={{ color: 'var(--text-strong)' }}>{selected.name}</b> 님의 예약을 다른 설명회로 이동해요. <b>예약번호와 QR은 그대로 유지</b>되며, 변경 확정 문자가 발송돼요.</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
            {sessions.filter((s) => s.id !== selected.sessionId).map((s) => {
              const left = s.capacity - seatsUsed(s.id);
              const full = left <= 0;
              const sel = moveTo === s.id;
              return (
                <div key={s.id} onClick={() => { if (!full) setMoveTo(s.id); }} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 15px', borderRadius: 'var(--radius-md)', cursor: full ? 'not-allowed' : 'pointer', opacity: full ? 0.5 : 1, background: sel ? 'var(--surface-brand-soft)' : 'var(--surface-card)', border: sel ? '1.5px solid var(--violet-800)' : '1px solid var(--border-hairline)', transition: 'all var(--dur-fast) var(--ease-out)' }}>
                  <span style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: 'var(--text-strong)' }}>{s.title}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-faint)', marginTop: 2 }}>{s.date} · {s.round} · {s.time}</div>
                  </span>
                  {full ? <Badge tone="neutral" size="sm">마감</Badge> : <Badge tone={left / s.capacity <= 0.15 ? 'warning' : 'brand'} size="sm">잔여 {left}석</Badge>}
                </div>
              );
            })}
          </div>
        </div>}
      </Dialog>

      <Dialog open={!!cancelTarget} onClose={() => setCancelTarget(null)} title="예약을 취소할까요?"
        footer={<React.Fragment><Button variant="ghost" onClick={() => setCancelTarget(null)}>돌아가기</Button><Button variant="danger" onClick={doCancel}>예약 취소</Button></React.Fragment>}>
        {cancelTarget && <span><b>{cancelTarget.name}</b> 님의 {session.title} 예약을 취소합니다. 취소 안내 문자가 자동 발송돼요.</span>}
      </Dialog>

      {toast && <div style={{ position: 'fixed', bottom: 26, left: '50%', transform: 'translateX(-50%)', zIndex: 120 }}><Toast tone="success">{toast}</Toast></div>}
    </div>
  );
}
window.PhoneScreen = PhoneScreen;
