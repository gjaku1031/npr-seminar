/* 모바일 예약 플로우 — 학부모 뷰 (프리뷰·실기기 공용) */
function MobileFlow({ store, compact }) {
  const { Button, Input, Badge, Select } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { sessions, students, reservations, addReservation, addReservationGroup, cancelReservation, moveReservation, addCounselBooking } = store;

  const [step, setStep] = React.useState('list'); // list | verify | guest | done | lookup | manage
  const [sessionId, setSessionId] = React.useState(null);
  const [phone, setPhone] = React.useState('');
  const [searched, setSearched] = React.useState(null);
  const [pickedIds, setPickedIds] = React.useState([]);
  const [attend, setAttend] = React.useState('1명');
  const [guest, setGuest] = React.useState({ name: '', school: '', grade: '', phone: '' });
  const [doneRecs, setDoneRecs] = React.useState(null);
  const [lookupPhone, setLookupPhone] = React.useState('');
  const [lookupCode, setLookupCode] = React.useState('');
  const [lookupErr, setLookupErr] = React.useState(false);
  const [manageId, setManageId] = React.useState(null);
  const [changeOpen, setChangeOpen] = React.useState(false);
  const [cancelOpen, setCancelOpen] = React.useState(false);
  const [surveySid, setSurveySid] = React.useState(null);
  const [survey, setSurvey] = React.useState({ rating: 0, q1: '', q2: '', q3: '', comment: '' });
  const [counselChosen, setCounselChosen] = React.useState(null);
  const [flash, setFlash] = React.useState(null);

  const session = sessions.find((s) => s.id === sessionId);
  const seatsUsed = (sid) => reservations.filter((r) => r.sessionId === sid && r.status !== 'cancelled').length;
  const pickedStudents = (searched || []).filter((s) => pickedIds.includes(s.id));
  const managed = reservations.find((r) => r.id === manageId);
  const managedSession = managed && sessions.find((s) => s.id === managed.sessionId);
  const toast = (m) => { setFlash(m); setTimeout(() => setFlash(null), 2600); };

  const search = () => {
    const digits = phone.replace(/\D/g, '');
    setPickedIds([]);
    setSearched(digits.length < 4 ? [] : students.filter((s) => s.parentPhone.replace(/\D/g, '').includes(digits)));
  };
  const togglePick = (id) => setPickedIds((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);
  const reset = () => { setStep('list'); setSessionId(null); setPhone(''); setSearched(null); setPickedIds([]); setGuest({ name: '', school: '', grade: '', phone: '' }); setDoneRecs(null); setAttend('1명'); setLookupPhone(''); setLookupCode(''); setLookupErr(false); setManageId(null); setSurveySid(null); setSurvey({ rating: 0, q1: '', q2: '', q3: '', comment: '' }); setCounselChosen(null); };

  const reserve = (isMember) => {
    const attendCount = parseInt(attend) || 1;
    if (isMember) {
      setDoneRecs(addReservationGroup({ sessionId }, pickedStudents, attendCount));
    } else {
      setDoneRecs([addReservation({ sessionId, studentId: null, name: guest.name, school: guest.school, grade: guest.grade, phone: guest.phone, channel: 'mobile', attendCount, member: false })]);
    }
    setStep('done');
  };

  const doLookup = () => {
    const digits = lookupPhone.replace(/\D/g, '');
    const code = lookupCode.trim().toUpperCase();
    const hit = reservations.find((r) => r.status !== 'cancelled' && digits.length >= 4 && r.phone.replace(/\D/g, '').includes(digits) && (code === '' || r.code.toUpperCase() === code));
    if (hit) { setManageId(hit.id); setLookupErr(false); setStep('manage'); }
    else setLookupErr(true);
  };
  const doCancel = () => { cancelReservation(managed.id, 'parent'); setCancelOpen(false); toast('예약을 취소했어요 — 취소 확인 문자를 보냈어요'); setTimeout(reset, 900); };
  const doChange = (toId) => { moveReservation(managed.id, toId); setChangeOpen(false); toast('예약을 변경했어요 — 변경 확정 문자를 보냈어요'); };

  const Head = ({ back, title }) =>
  <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 18px', position: 'sticky', top: 0, background: 'rgba(248,250,252,0.9)', backdropFilter: 'var(--blur-veil)', zIndex: 5 }}>
      {back ?
    <button onClick={back} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-strong)', display: 'inline-flex', padding: 4 }}><I.arrowLeft size={19} /></button> :
    <span style={{ width: 26, height: 26, borderRadius: 8, background: 'var(--violet-900)', color: 'var(--mint-400)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><I.ticket size={14} /></span>}
      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16.5, color: 'var(--violet-900)' }}>{title}</span>
    </div>;


  /* ── 설명회 선택 ── */
  if (step === 'list') return (
    <div data-screen-label="모바일 — 설명회 선택" style={{ minHeight: '100%', background: 'var(--surface-page)' }}>
      <Head title="npr 입시설명회" />
      <div style={{ padding: '10px 18px 30px' }}>
        <div style={{ padding: '20px 4px 16px' }}>
          <div style={{ fontSize: 11, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)' }}>RESERVATION</div>
          <h2 style={{ fontSize: 24, fontWeight: 800, marginTop: 6, lineHeight: 1.3 }}>설명회를 선택하고<br />바로 예약하세요</h2>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {sessions.map((s, i) => {
            const used = seatsUsed(s.id);
            const left = s.capacity - used;
            const full = left <= 0;
            return (
              <div key={s.id} onClick={() => {if (!full) {setSessionId(s.id);setStep('verify');}}}
              style={{ padding: '18px 20px', borderRadius: 'var(--radius-lg)', background: 'var(--surface-card)', border: '1px solid var(--border-hairline)', boxShadow: 'var(--shadow-card)', cursor: full ? 'default' : 'pointer', opacity: full ? 0.6 : 1, animation: `ds-fade-up var(--dur-slow) var(--ease-out) ${i * 80}ms both` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--text-strong)', lineHeight: 1.4 }}>{s.title}</div>
                  <I.arrowRight size={16} style={{ color: 'var(--violet-800)', flexShrink: 0, marginTop: 3 }} />
                </div>
                <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 6, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                  <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}><I.calendar size={12} /> {s.date} {s.time}</span>
                  <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}><I.mapPin size={12} /> {s.place}</span>
                  {s.notice && <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center', color: 'var(--mint-600)', fontWeight: 600 }}><I.message size={12} /> 안내문</span>}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12 }}>
                  <span style={{ flex: 1, height: 5, borderRadius: 3, background: 'var(--gray-2)', overflow: 'hidden' }}>
                    <span style={{ display: 'block', height: '100%', width: `${used / s.capacity * 100}%`, background: left / s.capacity <= 0.15 ? 'var(--status-danger)' : 'var(--violet-600)' }}></span>
                  </span>
                  {full ? <Badge tone="neutral" size="sm">마감</Badge> : left / s.capacity <= 0.15 ? <Badge tone="warning" dot size="sm">임박 {left}석</Badge> : <Badge tone="brand" size="sm">잔여 {left}석</Badge>}
                </div>
              </div>);

          })}
        </div>
        <div style={{ textAlign: 'center', marginTop: 22 }}>
          <a onClick={() => { setLookupPhone(''); setLookupCode(''); setLookupErr(false); setStep('lookup'); }} style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--violet-800)', textDecoration: 'underline', textUnderlineOffset: 3, cursor: 'pointer' }}>이미 예약했나요? 예약 조회 · 변경 · 취소</a>
        </div>
        <div style={{ textAlign: 'center', marginTop: 12 }}>
          <a onClick={() => { setSurveySid(sessions[0].id); setSurvey({ rating: 0, q1: '', q2: '', q3: '', comment: '' }); setStep('survey'); }} style={{ fontSize: 13, fontWeight: 700, color: 'var(--mint-600)', textDecoration: 'underline', textUnderlineOffset: 3, cursor: 'pointer' }}>참석하신 설명회 만족도 설문</a>
        </div>
      </div>
      {flash && <div style={{ position: compact ? 'absolute' : 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', background: 'var(--violet-900)', color: '#fff', padding: '11px 18px', borderRadius: 'var(--radius-pill)', fontSize: 13, fontWeight: 600, boxShadow: 'var(--shadow-raised)', zIndex: 30, animation: 'ds-pop var(--dur-base) var(--ease-spring) both' }}>{flash}</div>}
    </div>);


  /* ── 예약 조회 (학부모 셀프 변경·취소 진입) ── */
  if (step === 'lookup') return (
    <div data-screen-label="모바일 — 예약 조회" style={{ minHeight: '100%', background: 'var(--surface-page)' }}>
      <Head back={() => setStep('list')} title="예약 조회" />
      <div style={{ padding: '14px 18px 30px' }}>
        <div style={{ padding: '8px 4px 16px' }}>
          <h2 style={{ fontSize: 21, fontWeight: 800, lineHeight: 1.35 }}>예약을 조회해요</h2>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 5, lineHeight: 1.5 }}>예약 시 입력한 <b>학부모 연락처</b>로 조회하세요. 문자로 받은 <b>예약번호</b>를 함께 입력하면 정확해요.</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Input label="학부모 연락처" placeholder="010-0000-0000" value={lookupPhone} onChange={setLookupPhone} icon={<I.smartphone size={16} />} />
          <Input label="예약번호 (선택)" placeholder="NPR-SS1-0000" value={lookupCode} onChange={setLookupCode} icon={<I.ticket size={16} />} />
        </div>
        {lookupErr && <div style={{ marginTop: 12, padding: '12px 14px', borderRadius: 'var(--radius-md)', background: 'var(--status-danger-soft)', color: 'var(--status-danger)', fontSize: 13 }}>일치하는 예약이 없어요. 연락처를 다시 확인해 주세요.</div>}
        <Button size="lg" fullWidth onClick={doLookup} disabled={lookupPhone.replace(/\D/g, '').length < 4} style={{ marginTop: 18 }} icon={<I.search size={16} />}>예약 조회하기</Button>
      </div>
    </div>);


  /* ── 예약 관리 (티켓 + 변경/취소) ── */
  if (step === 'manage' && managed) return (
    <div data-screen-label="모바일 — 예약 관리" style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }}>
      <Head back={() => setStep('lookup')} title="내 예약" />
      <div style={{ flex: 1, padding: '14px 18px 30px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ width: '100%', maxWidth: 330, borderRadius: 'var(--radius-lg)', background: 'var(--surface-card)', boxShadow: 'var(--shadow-raised)', overflow: 'hidden', animation: 'ds-fade-up var(--dur-slow) var(--ease-spring) both' }}>
          <div style={{ background: 'var(--surface-brand)', color: 'var(--text-on-brand)', padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
            <div>
              <div style={{ fontSize: 10.5, letterSpacing: 'var(--tracking-caps)', color: 'var(--mint-400)', fontWeight: 700 }}>NPR ADMISSION QR</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, marginTop: 4, lineHeight: 1.35 }}>{managedSession.title}</div>
            </div>
            <ResStatusBadge status={managed.status} size="sm" />
          </div>
          <div style={{ padding: '18px 20px', display: 'flex', gap: 16, alignItems: 'center' }}>
            <QrBox code={managed.code} size={104} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9, minWidth: 0 }}>
              <KV k="예약자" v={managed.name} />
              <KV k="일시" v={`${managedSession.date} ${managedSession.time}`} />
              <KV k="예약번호" v={<span style={{ fontFeatureSettings: '"tnum"', fontSize: 12.5 }}>{managed.code}</span>} />
            </div>
          </div>
          {managed.history && managed.history.length > 0 && <div style={{ padding: '0 20px 14px', fontSize: 11.5, color: 'var(--text-faint)', display: 'flex', gap: 5, alignItems: 'center' }}><I.calendar size={12} /> 회차 변경 {managed.history.length}회 · 예약번호 유지</div>}
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 22, width: '100%', maxWidth: 330 }}>
          <Button variant="secondary" fullWidth icon={<I.calendar size={15} />} onClick={() => setChangeOpen(true)}>예약 변경</Button>
          <Button variant="danger" fullWidth onClick={() => setCancelOpen(true)}>예약 취소</Button>
        </div>
      </div>

      {changeOpen && <div onClick={() => setChangeOpen(false)} style={{ position: compact ? 'absolute' : 'fixed', inset: 0, background: 'rgba(15,23,42,0.4)', backdropFilter: 'var(--blur-veil)', zIndex: 40, display: 'flex', alignItems: 'flex-end', animation: 'ds-fade-in var(--dur-fast) both' }}>
        <div onClick={(e) => e.stopPropagation()} style={{ width: '100%', background: 'var(--surface-page)', borderRadius: '22px 22px 0 0', padding: '10px 18px 26px', animation: 'ds-sheet-up var(--dur-base) var(--ease-spring) both' }}>
          <div style={{ width: 38, height: 4, borderRadius: 2, background: 'var(--gray-3)', margin: '6px auto 14px' }}></div>
          <h3 style={{ fontSize: 17, fontWeight: 800 }}>다른 설명회로 변경</h3>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 4, marginBottom: 12 }}>예약번호와 QR은 그대로 유지돼요.</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {sessions.filter((s) => s.id !== managed.sessionId).map((s) => {
              const left = s.capacity - seatsUsed(s.id);
              const full = left <= 0;
              return (
                <div key={s.id} onClick={() => { if (!full) doChange(s.id); }} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 'var(--radius-lg)', cursor: full ? 'not-allowed' : 'pointer', opacity: full ? 0.5 : 1, background: 'var(--surface-card)', border: '1px solid var(--border-hairline)', boxShadow: 'var(--shadow-card)' }}>
                  <span style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text-strong)' }}>{s.title}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-faint)', marginTop: 2 }}>{s.date} · {s.round} · {s.time}</div>
                  </span>
                  {full ? <Badge tone="neutral" size="sm">마감</Badge> : <Badge tone={left / s.capacity <= 0.15 ? 'warning' : 'brand'} size="sm">잔여 {left}석</Badge>}
                </div>
              );
            })}
          </div>
        </div>
      </div>}

      {cancelOpen && <div onClick={() => setCancelOpen(false)} style={{ position: compact ? 'absolute' : 'fixed', inset: 0, background: 'rgba(15,23,42,0.4)', backdropFilter: 'var(--blur-veil)', zIndex: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, animation: 'ds-fade-in var(--dur-fast) both' }}>
        <div onClick={(e) => e.stopPropagation()} style={{ width: '100%', maxWidth: 320, background: 'var(--surface-card)', borderRadius: 'var(--radius-lg)', padding: '22px 22px 18px', boxShadow: 'var(--shadow-raised)', animation: 'ds-pop var(--dur-base) var(--ease-spring) both' }}>
          <h3 style={{ fontSize: 17, fontWeight: 800 }}>예약을 취소할까요?</h3>
          <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 8, lineHeight: 1.55 }}>{managed.name} 학생의 {managedSession.title} 예약을 취소해요. 취소는 시작 24시간 전까지 가능해요.</div>
          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <Button variant="ghost" fullWidth onClick={() => setCancelOpen(false)}>돌아가기</Button>
            <Button variant="danger" fullWidth onClick={doCancel}>취소하기</Button>
          </div>
        </div>
      </div>}

      {flash && <div style={{ position: compact ? 'absolute' : 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', background: 'var(--violet-900)', color: '#fff', padding: '11px 18px', borderRadius: 'var(--radius-pill)', fontSize: 13, fontWeight: 600, boxShadow: 'var(--shadow-raised)', zIndex: 50, textAlign: 'center', animation: 'ds-pop var(--dur-base) var(--ease-spring) both' }}>{flash}</div>}
    </div>);


  /* ── 재원생 조회 ── */
  if (step === 'verify') return (
    <div data-screen-label="모바일 — 재원생 조회" style={{ minHeight: '100%', background: 'var(--surface-page)' }}>
      <Head back={() => {setStep('list');setSearched(null);setPickedIds([]);}} title="재원생 예약" />
      <div style={{ padding: '14px 18px 110px' }}>
        <div style={{ padding: '8px 4px 16px' }}>
          <h2 style={{ fontSize: 21, fontWeight: 800, lineHeight: 1.35 }}>{session.title}</h2>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 5 }}>{session.date} {session.time} · {session.place}</div>
        </div>
        {session.notice &&
        <div style={{ display: 'flex', gap: 9, alignItems: 'flex-start', padding: '12px 14px', marginBottom: 16, borderRadius: 'var(--radius-md)', background: 'var(--surface-accent-soft)', color: 'var(--mint-700)', fontSize: 12.5, lineHeight: 1.55 }}>
          <I.message size={15} style={{ flexShrink: 0, marginTop: 1 }} /><span>{session.notice}</span>
        </div>
        }
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
          <Input label="학부모 연락처로 재원생 조회" placeholder="010-0000-0000" value={phone} onChange={setPhone} icon={<I.smartphone size={16} />} style={{ flex: 1 }} />
          <Button variant="secondary" onClick={search}>조회</Button>
        </div>
        {searched && searched.length > 1 &&
        <div style={{ marginTop: 12, padding: '10px 14px', borderRadius: 'var(--radius-md)', background: 'var(--surface-accent-soft)', color: 'var(--mint-700)', fontSize: 12.5, display: 'flex', gap: 8, alignItems: 'center', lineHeight: 1.45 }}><I.users size={15} style={{ flexShrink: 0 }} /> 형제·자매를 <b>함께 선택</b>하면 자녀별로 각각 QR이 발급돼요.</div>
        }
        {searched && searched.length === 0 &&
        <div style={{ marginTop: 12, padding: '12px 14px', borderRadius: 'var(--radius-md)', background: 'var(--status-danger-soft)', color: 'var(--status-danger)', fontSize: 13 }}>일치하는 재원생이 없어요. 번호를 확인하거나 아래 비재원생 예약을 이용해 주세요.</div>
        }
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 14 }}>
          {searched && searched.slice(0, 3).map((s, i) => {
            const sel = pickedIds.includes(s.id);
            return (
              <div key={s.id} onClick={() => togglePick(s.id)}
              style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '15px 16px', borderRadius: 'var(--radius-lg)', cursor: 'pointer', background: sel ? 'var(--surface-brand-soft)' : 'var(--surface-card)', border: sel ? '1.5px solid var(--violet-800)' : '1px solid var(--border-hairline)', boxShadow: sel ? 'var(--shadow-accent-glow)' : 'var(--shadow-card)', transform: sel ? 'scale(1.015)' : 'scale(1)', transition: 'all var(--dur-base) var(--ease-spring)', animation: `ds-pop var(--dur-base) var(--ease-spring) ${i * 70}ms both` }}>
                <span style={{ width: 44, height: 44, borderRadius: '50%', background: 'var(--violet-100)', color: 'var(--violet-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 15, flexShrink: 0 }}>{s.name[0]}</span>
                <span style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, fontSize: 15.5, color: 'var(--text-strong)' }}>{s.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>{s.school} · {s.grade}</div>
                </span>
                <span style={{ width: 24, height: 24, borderRadius: 8, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: sel ? 'var(--violet-900)' : 'var(--surface-card)', border: sel ? '1.5px solid var(--violet-900)' : '1.5px solid var(--border-soft)', transition: 'all var(--dur-fast) var(--ease-spring)', boxSizing: 'border-box', flexShrink: 0 }}>{sel && <I.check size={14} sw={3} style={{ color: '#fff' }} />}</span>
              </div>);

          })}
        </div>
        {pickedIds.length > 0 && session.attendField &&
        <div style={{ marginTop: 14, animation: 'ds-fade-up var(--dur-base) var(--ease-out) both' }}>
            <Select label={pickedIds.length > 1 ? '자녀당 참석 인원' : '참석 인원'} options={['1명', '2명', '3명', '4명']} value={attend} onChange={setAttend} />
          </div>
        }
        <div style={{ textAlign: 'center', marginTop: 22 }}>
          <a onClick={() => setStep('guest')} style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--mint-600)', textDecoration: 'underline', textUnderlineOffset: 3, cursor: 'pointer' }}>비재원생 예약하기</a>
        </div>
      </div>
      <div style={{ position: compact ? 'absolute' : 'fixed', left: 0, right: 0, bottom: 0, padding: '12px 18px 20px', background: 'rgba(248,250,252,0.92)', backdropFilter: 'var(--blur-veil)', borderTop: '1px solid var(--border-hairline)', zIndex: 6 }}>
        <Button size="lg" fullWidth disabled={pickedIds.length === 0} onClick={() => reserve(true)} iconRight={<I.arrowRight size={17} />}>
          {pickedIds.length === 0 ? '학생을 선택해 주세요' : pickedIds.length === 1 ? `${pickedStudents[0].name} 학생으로 예약하기` : `${pickedIds.length}명 예약하기`}
        </Button>
      </div>
    </div>);


  /* ── 비재원생 폼 ── */
  if (step === 'guest') return (
    <div data-screen-label="모바일 — 비재원생 예약" style={{ minHeight: '100%', background: 'var(--surface-page)' }}>
      <Head back={() => setStep('verify')} title="비재원생 예약" />
      <div style={{ padding: '14px 18px 110px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ padding: '8px 4px 2px' }}>
          <h2 style={{ fontSize: 21, fontWeight: 800, lineHeight: 1.35 }}>{session.title}</h2>
          <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 5 }}>{session.date} {session.time} · {session.place}</div>
        </div>
        <Input label="학생 이름" placeholder="정하윤" value={guest.name} onChange={(v) => setGuest({ ...guest, name: v })} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Input label="학교" placeholder="동성중" value={guest.school} onChange={(v) => setGuest({ ...guest, school: v })} />
          <Input label="학년" placeholder="중3" value={guest.grade} onChange={(v) => setGuest({ ...guest, grade: v })} />
        </div>
        <Input label="학부모 연락처" placeholder="010-0000-0000" value={guest.phone} onChange={(v) => setGuest({ ...guest, phone: v })} hint="QR이 담긴 확정 문자를 이 번호로 보내드려요" />
        {session.attendField && <Select label="참석 인원" options={['1명', '2명', '3명', '4명']} value={attend} onChange={setAttend} />}
      </div>
      <div style={{ position: compact ? 'absolute' : 'fixed', left: 0, right: 0, bottom: 0, padding: '12px 18px 20px', background: 'rgba(248,250,252,0.92)', backdropFilter: 'var(--blur-veil)', borderTop: '1px solid var(--border-hairline)', zIndex: 6 }}>
        <Button size="lg" fullWidth disabled={!guest.name || !guest.phone} onClick={() => reserve(false)} iconRight={<I.arrowRight size={17} />}>예약하기</Button>
      </div>
    </div>);


  /* ── 만족도 설문 ── */
  if (step === 'survey' || step === 'surveyDone') {
    const surveySession = sessions.find((s) => s.id === surveySid) || sessions[0];
    const RadioRow = ({ q, opts, value, onPick }) => (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
        <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>{q}</span>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {opts.map((o) => <button key={o} onClick={() => onPick(o)} style={{ padding: '9px 14px', borderRadius: 'var(--radius-pill)', border: value === o ? '1.5px solid var(--violet-800)' : '1px solid var(--border-soft)', background: value === o ? 'var(--surface-brand-soft)' : 'var(--surface-card)', color: value === o ? 'var(--violet-800)' : 'var(--text-body)', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-body)', transition: 'all var(--dur-fast) var(--ease-out)' }}>{o}</button>)}
        </div>
      </div>
    );
    if (step === 'surveyDone') return (
      <div data-screen-label="모바일 — 설문 완료" style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }}>
        <Head title="설문 완료" />
        <div style={{ flex: 1, padding: '40px 22px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
          <span style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--mint-500)', color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', animation: 'ds-pop var(--dur-hero) var(--ease-spring) both' }}><I.check size={26} sw={2.6} /></span>
          <h2 style={{ fontSize: 22, fontWeight: 800, marginTop: 16 }}>소중한 의견 감사해요</h2>
          <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginTop: 8, lineHeight: 1.6 }}>보내주신 피드백은 다음 설명회를<br />더 잘 준비하는 데 큰 도움이 돼요.</p>
          <Button onClick={reset} style={{ marginTop: 26 }}>처음으로</Button>
        </div>
      </div>);
    return (
      <div data-screen-label="모바일 — 만족도 설문" style={{ minHeight: '100%', background: 'var(--surface-page)' }}>
        <Head back={() => setStep('list')} title="만족도 설문" />
        <div style={{ padding: '14px 18px 120px', display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div style={{ padding: '4px 2px' }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, lineHeight: 1.35 }}>{surveySession.title}</h2>
            <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 5 }}>설명회는 어떻셨나요? 잠시면 돼요.</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'center', padding: '18px 0', borderRadius: 'var(--radius-lg)', background: 'var(--surface-card)', border: '1px solid var(--border-hairline)', boxShadow: 'var(--shadow-card)' }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>전반적인 만족도</span>
            <div style={{ display: 'flex', gap: 6 }}>
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} onClick={() => setSurvey({ ...survey, rating: n })} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2, transition: 'transform var(--dur-fast) var(--ease-spring)', transform: survey.rating === n ? 'scale(1.15)' : 'scale(1)' }}>
                  <I.star size={34} style={{ color: n <= survey.rating ? 'var(--mint-500)' : 'var(--gray-3)', fill: n <= survey.rating ? 'var(--mint-500)' : 'none' }} />
                </button>
              ))}
            </div>
            <span style={{ fontSize: 12, color: 'var(--text-faint)', minHeight: 16 }}>{survey.rating ? ['', '아쉬워요', '보통이에요', '괜첂아요', '좋았어요', '매우 좋았어요'][survey.rating] : '별을 탑해 주세요'}</span>
          </div>
          <RadioRow q="설명회가 진학에 도움이 되었나요?" opts={['매우 도움됨', '도움됨', '보통', '아쉬움']} value={survey.q1} onPick={(v) => setSurvey({ ...survey, q1: v })} />
          <RadioRow q="안내와 진행은 어떠셨나요?" opts={['만족', '보통', '아쉬움']} value={survey.q2} onPick={(v) => setSurvey({ ...survey, q2: v })} />
          <RadioRow q="다음 설명회에도 참여하시겠어요?" opts={['네', '미정', '아니오']} value={survey.q3} onPick={(v) => setSurvey({ ...survey, q3: v })} />
          <label style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>개선할 점이나 하고 싶은 말 <span style={{ color: 'var(--text-faint)', fontWeight: 500 }}>(선택)</span></span>
            <textarea value={survey.comment} onChange={(e) => setSurvey({ ...survey, comment: e.target.value })} rows={3} placeholder="자유롭게 적어 주세요" style={{ width: '100%', padding: '12px 14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-soft)', background: 'var(--surface-card)', fontFamily: 'var(--font-body)', fontSize: 14, lineHeight: 1.6, color: 'var(--text-strong)', resize: 'vertical', outline: 'none', boxSizing: 'border-box' }} />
          </label>
        </div>
        <div style={{ position: compact ? 'absolute' : 'fixed', left: 0, right: 0, bottom: 0, padding: '12px 18px 20px', background: 'rgba(248,250,252,0.92)', backdropFilter: 'var(--blur-veil)', borderTop: '1px solid var(--border-hairline)', zIndex: 6 }}>
          <Button size="lg" fullWidth disabled={!survey.rating} onClick={() => setStep('surveyDone')}>설문 제출하기</Button>
        </div>
      </div>);
  }


  /* ── 상담 신청 ── */
  if (step === 'counsel' || step === 'counselDone') {
    const who = (doneRecs && doneRecs[0]) || {};
    const slots = store.counselSlots || [];
    const tchers = store.teachers || [];
    const tName = (id) => (tchers.find((t) => t.id === id) || {}).name || '';
    const usedTeachers = [...new Set(slots.map((s) => s.teacherId))];
    const book = (slot) => { addCounselBooking(slot.id, { name: who.name, grade: who.grade, phone: who.phone, from: sessionId }); setCounselChosen({ ...slot, teacherName: tName(slot.teacherId) }); setStep('counselDone'); };
    if (step === 'counselDone') return (
      <div data-screen-label="모바일 — 상담 신청 완료" style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }}>
        <Head title="상담 신청 완료" />
        <div style={{ flex: 1, padding: '30px 22px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
          <span style={{ width: 54, height: 54, borderRadius: '50%', background: 'var(--violet-900)', color: 'var(--mint-400)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', animation: 'ds-pop var(--dur-hero) var(--ease-spring) both' }}><I.check size={24} sw={2.6} /></span>
          <h2 style={{ fontSize: 22, fontWeight: 800, marginTop: 16 }}>상담이 신청됐어요</h2>
          {counselChosen && <div style={{ width: '100%', maxWidth: 300, marginTop: 18, padding: '16px 20px', borderRadius: 'var(--radius-lg)', background: 'var(--surface-card)', boxShadow: 'var(--shadow-card)', border: '1px solid var(--border-hairline)', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 10 }}>
            <KV k="상담 선생님" v={`${counselChosen.teacherName} 강사`} />
            <KV k="일시" v={`${counselChosen.date} ${counselChosen.time}`} />
          </div>}
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 14, lineHeight: 1.6 }}>상담 확정 문자를 발송해 드려요.<br />전일 리마인드도 보내드려요.</p>
          <Button onClick={reset} style={{ marginTop: 24 }}>처음으로</Button>
        </div>
      </div>);
    return (
      <div data-screen-label="모바일 — 상담 신청" style={{ minHeight: '100%', background: 'var(--surface-page)' }}>
        <Head back={() => setStep('done')} title="개별 상담 신청" />
        <div style={{ padding: '14px 18px 30px' }}>
          <div style={{ padding: '4px 2px 16px' }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, lineHeight: 1.35 }}>설명회에서 못다 한 이야기,<br />개별 상담으로 이어가세요</h2>
            <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 6 }}>원하는 선생님과 시간을 골라 주세요.</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {usedTeachers.map((tid) => {
              const avail = slots.filter((s) => s.teacherId === tid && !s.booked);
              return (
                <div key={tid}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
                    <span style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--violet-100)', color: 'var(--violet-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13 }}>{tName(tid)[0]}</span>
                    <span style={{ fontSize: 14.5, fontWeight: 800, color: 'var(--text-strong)' }}>{tName(tid)} 강사</span>
                  </div>
                  {avail.length === 0 ? <div style={{ fontSize: 12.5, color: 'var(--text-faint)', paddingLeft: 41 }}>가능한 시간이 없어요.</div> : (
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', paddingLeft: 41 }}>
                      {avail.map((s) => (
                        <button key={s.id} onClick={() => book(s)} style={{ padding: '9px 13px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-soft)', background: 'var(--surface-card)', cursor: 'pointer', fontFamily: 'var(--font-body)', textAlign: 'left', transition: 'all var(--dur-fast) var(--ease-out)' }} onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--violet-800)'; e.currentTarget.style.background = 'var(--surface-brand-soft)'; }} onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border-soft)'; e.currentTarget.style.background = 'var(--surface-card)'; }}>
                          <div style={{ fontSize: 11, color: 'var(--text-faint)' }}>{s.date.replace(/ \(.\)/, '')}</div>
                          <div style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text-strong)', fontFeatureSettings: '"tnum"' }}>{s.time}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>);
  }


  /* ── 예약 완료 ── */
  const primary = doneRecs && doneRecs[0];
  return (
    <div data-screen-label="모바일 — 예약 완료" style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }}>
      <Head title="예약 완료" />
      <div style={{ flex: 1, padding: '20px 18px 30px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <span style={{ width: 54, height: 54, borderRadius: '50%', background: 'var(--violet-900)', color: 'var(--mint-400)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', animation: 'ds-pop var(--dur-hero) var(--ease-spring) both' }}><I.check size={24} sw={2.6} /></span>
        <h2 style={{ fontSize: 23, fontWeight: 800, marginTop: 14, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 120ms both' }}>{doneRecs.length > 1 ? `${doneRecs.length}명 예약이 확정됐어요!` : '예약이 확정됐어요!'}</h2>

        <div style={{ width: '100%', maxWidth: 330, marginTop: 20, borderRadius: 'var(--radius-lg)', background: 'var(--surface-card)', boxShadow: 'var(--shadow-raised)', overflow: 'hidden', animation: 'ds-fade-up var(--dur-hero) var(--ease-spring) 200ms both' }}>
          <div style={{ background: 'var(--surface-brand)', color: 'var(--text-on-brand)', padding: '16px 20px' }}>
            <div style={{ fontSize: 10.5, letterSpacing: 'var(--tracking-caps)', color: 'var(--mint-400)', fontWeight: 700 }}>NPR ADMISSION QR</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16.5, marginTop: 4, lineHeight: 1.35 }}>{session.title}</div>
          </div>
          <div style={{ padding: '18px 20px', display: 'flex', gap: 16, alignItems: 'center' }}>
            <QrBox code={primary.code} size={112} style={{ animation: 'ds-pop var(--dur-slow) var(--ease-spring) 400ms both' }} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9, minWidth: 0 }}>
              <KV k="예약자" v={primary.name} />
              <KV k="일시" v={`${session.date} ${session.time}`} />
              {session.attendField && <KV k="참석 인원" v={`${primary.attendCount}명`} />}
              <KV k="예약번호" v={<span style={{ fontFeatureSettings: '"tnum"', fontSize: 12.5, letterSpacing: '0.03em' }}>{primary.code}</span>} />
            </div>
          </div>
          <div style={{ borderTop: '2px dashed var(--gray-3)', margin: '0 -13px', position: 'relative' }}>
            <span style={{ position: 'absolute', left: 0, top: -12, width: 24, height: 24, borderRadius: '50%', background: 'var(--surface-page)' }}></span>
            <span style={{ position: 'absolute', right: 0, top: -12, width: 24, height: 24, borderRadius: '50%', background: 'var(--surface-page)' }}></span>
          </div>
          <div style={{ padding: '14px 20px 18px', background: 'var(--surface-accent-soft)', display: 'flex', gap: 10, alignItems: 'flex-start', fontSize: 12.5, color: 'var(--mint-700)', lineHeight: 1.55 }}>
            <I.message size={15} style={{ flexShrink: 0, marginTop: 2 }} />
            <span><b>{primary.phone}</b>로 QR이 담긴 문자를 발송했어요. 입장 시 태블릿에 QR을 보여주세요.</span>
          </div>
        </div>

        {doneRecs.length > 1 &&
        <div style={{ width: '100%', maxWidth: 330, marginTop: 12, borderRadius: 'var(--radius-lg)', background: 'var(--surface-card)', border: '1px solid var(--border-hairline)', padding: '14px 18px', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 420ms both' }}>
          <div style={{ fontSize: 11.5, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-faint)', marginBottom: 8 }}>함께 예약된 자녀 {doneRecs.length}명</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {doneRecs.map((r) => (
              <div key={r.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ width: 30, height: 30, borderRadius: '50%', background: 'var(--violet-100)', color: 'var(--violet-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 12, flexShrink: 0 }}>{r.name[0]}</span>
                <span style={{ flex: 1, fontSize: 13.5, fontWeight: 700, color: 'var(--text-strong)' }}>{r.name}</span>
                <span style={{ fontSize: 11.5, color: 'var(--text-faint)', fontFeatureSettings: '"tnum"' }}>{r.code}</span>
              </div>
            ))}
          </div>
        </div>
        }

        <div style={{ width: '100%', maxWidth: 330, marginTop: 22, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 460ms both' }}>
          <button onClick={() => setStep('counsel')} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', borderRadius: 'var(--radius-lg)', background: 'var(--surface-accent-soft)', border: '1px solid var(--mint-200)', cursor: 'pointer', textAlign: 'left', fontFamily: 'var(--font-body)' }}>
            <span style={{ width: 38, height: 38, borderRadius: 'var(--radius-sm)', background: 'var(--mint-500)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><I.clipboard size={18} /></span>
            <span style={{ flex: 1 }}>
              <span style={{ display: 'block', fontSize: 14, fontWeight: 800, color: 'var(--mint-700)' }}>개별 상담 신청하기</span>
              <span style={{ display: 'block', fontSize: 12, color: 'var(--mint-600)', marginTop: 2 }}>선생님과 1:1 상담 시간을 예약하세요</span>
            </span>
            <I.arrowRight size={16} style={{ color: 'var(--mint-600)' }} />
          </button>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 14, width: '100%', maxWidth: 330, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 520ms both' }}>
          <Button variant="secondary" fullWidth icon={<I.calendar size={15} />}>캘린더 추가</Button>
          <Button fullWidth onClick={reset}>처음으로</Button>
        </div>
      </div>
    </div>);

}
window.MobileFlow = MobileFlow;