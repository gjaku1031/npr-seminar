# 자동 생성 — 원본(진실원): flow-data.js / flows.json. 직접 수정하지 말고 원본에서 재생성.
# npr 입시설명회 운영 시스템 · 권한별 E2E 유저플로우

Feature: 실장 — 운영 실무 총괄 · 원장 대행
  목표: 원장과 100% 동일 권한으로 일상 운영 전반을 집행한다.
  진입: 로그인(실장) → 허브 8개 모듈 전체 (원장과 동일)
  권한: ✓ 원장과 동일 / ✓ 전체 8모듈 / ✓ 통계
  참고: 실장 권한은 원장과 100% 동일합니다. 아래 플로우는 원장(OWNER-*)과 동일한 흐름을 그대로 따릅니다.

  # ===== OWNER-F1 · 로그인 & 라우팅 (역할 판별 → 허브 → 모듈 이동) =====

  Scenario: OWNER-F1 · 로그인 & 라우팅 — 재원생 관리
    Given [OWNER-F1-01] 콘솔 접속 (index.html)
    When [OWNER-F1-02] 로그인 화면
    And [OWNER-F1-03] 원장 선택 → 입장하기
    Then [OWNER-F1-04] 상태 변화: npr-user = owner
    When [OWNER-F1-05] 허브 (카드 런처)
    And [OWNER-F1-06] 모듈 진입 → 재원생 관리
    And [OWNER-F1-06a] → F2
    And [OWNER-F1-07] 아바타 메뉴 → 로그아웃
    Then [OWNER-F1-08] 로그인 화면 복귀 (npr-user 삭제)

  Scenario: OWNER-F1 · 로그인 & 라우팅 — 설명회 운영
    Given [OWNER-F1-01] 콘솔 접속 (index.html)
    When [OWNER-F1-02] 로그인 화면
    And [OWNER-F1-03] 원장 선택 → 입장하기
    Then [OWNER-F1-04] 상태 변화: npr-user = owner
    When [OWNER-F1-05] 허브 (카드 런처)
    And [OWNER-F1-06] 모듈 진입 → 설명회 운영
    And [OWNER-F1-06b] → F5 (QR 현황 대시보드)
    And [OWNER-F1-07] 아바타 메뉴 → 로그아웃
    Then [OWNER-F1-08] 로그인 화면 복귀 (npr-user 삭제)

  Scenario: OWNER-F1 · 로그인 & 라우팅 — 통계
    Given [OWNER-F1-01] 콘솔 접속 (index.html)
    When [OWNER-F1-02] 로그인 화면
    And [OWNER-F1-03] 원장 선택 → 입장하기
    Then [OWNER-F1-04] 상태 변화: npr-user = owner
    When [OWNER-F1-05] 허브 (카드 런처)
    And [OWNER-F1-06] 모듈 진입 → 통계
    And [OWNER-F1-06c] → F7
    And [OWNER-F1-07] 아바타 메뉴 → 로그아웃
    Then [OWNER-F1-08] 로그인 화면 복귀 (npr-user 삭제)

  # ===== OWNER-F2 · 재원생 관리 (전체 명단) (원장·실장 전용) =====

  Scenario: OWNER-F2 · 재원생 관리 (전체 명단) — 학생 추가 / 유효
    Given [OWNER-F2-01] 재원생 명단 진입
    When [OWNER-F2-02] 필터
    And [OWNER-F2-03] 우상단 액션 → 학생 추가
    And [OWNER-F2-04] 학생 추가 모달
    And [OWNER-F2-05] 이름·연락처 입력? → 유효
    Then [OWNER-F2-06] 상태 변화: +Student

  Scenario: OWNER-F2 · 재원생 관리 (전체 명단) — 엑셀 업로드 / 중복
    Given [OWNER-F2-01] 재원생 명단 진입
    When [OWNER-F2-02] 필터
    And [OWNER-F2-03] 우상단 액션 → 엑셀 업로드
    And [OWNER-F2-07] 매핑 미리보기 모달
    And [OWNER-F2-08] 연락처 중복? → 중복
    Then [OWNER-F2-09] 상태 변화: 기존 재원생 병합

  Scenario: OWNER-F2 · 재원생 관리 (전체 명단) — 엑셀 업로드 / 신규
    Given [OWNER-F2-01] 재원생 명단 진입
    When [OWNER-F2-02] 필터
    And [OWNER-F2-03] 우상단 액션 → 엑셀 업로드
    And [OWNER-F2-07] 매핑 미리보기 모달
    And [OWNER-F2-08] 연락처 중복? → 신규
    Then [OWNER-F2-10] 상태 변화: +Student

  Scenario: OWNER-F2 · 재원생 관리 (전체 명단) — 엑셀 다운로드
    Given [OWNER-F2-01] 재원생 명단 진입
    When [OWNER-F2-02] 필터
    And [OWNER-F2-03] 우상단 액션 → 엑셀 다운로드
    And [OWNER-F2-11] 현재 필터 명단 .xlsx 내려받기

  # ===== OWNER-F3 · 전화예약 관리 (수동예약 · QR/문자 상세) =====

  Scenario: OWNER-F3 · 전화예약 관리 — 재원생 탭 / true / 문자 재발송
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 재원생 탭
    And [OWNER-F3-04] 연락처(부분) 조회 → 학생 카드 선택
    And [OWNER-F3-05] attendField? → true
    And [OWNER-F3-06] 참석 인원(1~4) 선택
    Then [OWNER-F3-07] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → 문자 재발송
    Then [OWNER-F3-12] 문자 발송: 예약 확정 + QR

  Scenario: OWNER-F3 · 전화예약 관리 — 비재원생 탭 / 문자 재발송
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 비재원생 탭
    And [OWNER-F3-08] 이름·학교·학년·연락처 입력
    Then [OWNER-F3-09] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → 문자 재발송
    Then [OWNER-F3-12] 문자 발송: 예약 확정 + QR

  Scenario: OWNER-F3 · 전화예약 관리 — 재원생 탭 / true / QR 재발급
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 재원생 탭
    And [OWNER-F3-04] 연락처(부분) 조회 → 학생 카드 선택
    And [OWNER-F3-05] attendField? → true
    And [OWNER-F3-06] 참석 인원(1~4) 선택
    Then [OWNER-F3-07] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → QR 재발급
    Then [OWNER-F3-13] 상태 변화: code → -Rn (codeHistory)
    And 문자 발송: 재발급 QR

  Scenario: OWNER-F3 · 전화예약 관리 — 비재원생 탭 / QR 재발급
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 비재원생 탭
    And [OWNER-F3-08] 이름·학교·학년·연락처 입력
    Then [OWNER-F3-09] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → QR 재발급
    Then [OWNER-F3-13] 상태 변화: code → -Rn (codeHistory)
    And 문자 발송: 재발급 QR

  Scenario: OWNER-F3 · 전화예약 관리 — 재원생 탭 / true / 예약 변경
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 재원생 탭
    And [OWNER-F3-04] 연락처(부분) 조회 → 학생 카드 선택
    And [OWNER-F3-05] attendField? → true
    And [OWNER-F3-06] 참석 인원(1~4) 선택
    Then [OWNER-F3-07] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → 예약 변경
    And [OWNER-F3-14] 회차 선택 다이얼로그(잔여석)
    Then [OWNER-F3-15] 상태 변화: sessionId 이동 · history[]
    And 문자 발송: 변경 확정

  Scenario: OWNER-F3 · 전화예약 관리 — 비재원생 탭 / 예약 변경
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 비재원생 탭
    And [OWNER-F3-08] 이름·학교·학년·연락처 입력
    Then [OWNER-F3-09] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → 예약 변경
    And [OWNER-F3-14] 회차 선택 다이얼로그(잔여석)
    Then [OWNER-F3-15] 상태 변화: sessionId 이동 · history[]
    And 문자 발송: 변경 확정

  Scenario: OWNER-F3 · 전화예약 관리 — 재원생 탭 / true / 예약 취소
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 재원생 탭
    And [OWNER-F3-04] 연락처(부분) 조회 → 학생 카드 선택
    And [OWNER-F3-05] attendField? → true
    And [OWNER-F3-06] 참석 인원(1~4) 선택
    Then [OWNER-F3-07] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → 예약 취소
    And [OWNER-F3-16] 취소 확인 다이얼로그
    Then [OWNER-F3-17] 상태 변화: → cancelled (by staff)
    And 문자 발송: 취소 안내

  Scenario: OWNER-F3 · 전화예약 관리 — 비재원생 탭 / 예약 취소
    Given [OWNER-F3-01] 전화예약 진입 + 설명회 선택
    When [OWNER-F3-02] 스탯 카드 클릭 = 목록 필터
    And [OWNER-F3-03] 수동예약 등록 → 비재원생 탭
    And [OWNER-F3-08] 이름·학교·학년·연락처 입력
    Then [OWNER-F3-09] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F3-10] 예약 상세 패널 (행 클릭)
    And [OWNER-F3-11] 상세 액션 → 예약 취소
    And [OWNER-F3-16] 취소 확인 다이얼로그
    Then [OWNER-F3-17] 상태 변화: → cancelled (by staff)
    And 문자 발송: 취소 안내

  # ===== OWNER-F4 · 문자 발송 (템플릿 · 대상 · 로그) =====

  Scenario: OWNER-F4 · 문자 발송 — 가능
    Given [OWNER-F4-01] 문자 발송 진입
    When [OWNER-F4-02] 템플릿 선택 / 생성 / 저장
    And [OWNER-F4-03] 본문 편집 + 변수 칩
    And [OWNER-F4-04] 수신 대상 선택
    And [OWNER-F4-05] 발송 가능? → 가능
    Then [OWNER-F4-06] 상태 변화: 발송 → 로그 추가
    And 문자 발송: 선택 템플릿 · 대상 그룹
    When [OWNER-F4-07] 발송 로그 대시보드

  # ===== OWNER-F5 · 설명회 운영 — QR 현황 대시보드 (전체 명단 관리 · 핵심) =====

  Scenario: OWNER-F5 · 설명회 운영 — QR 현황 대시보드 — 미예약 (재학생) / 종료 처리 / 삭제 확인
    Given [OWNER-F5-01] 설명회 운영 진입 + 좌측 설명회 선택
    When [OWNER-F5-02] 새 설명회 생성
    Then [OWNER-F5-03] 상태 변화: +Session
    When [OWNER-F5-04] 현황 헤더 + 스탯 5장
    And [OWNER-F5-05] 리마인드 스케줄 토글 / 지금 발송
    Then 문자 발송: 전일·당일 리마인드 (자동 배지)
    When [OWNER-F5-06] 설문 보내기 (입장>0)
    Then 문자 발송: 만족도 설문 링크
    When [OWNER-F5-07] 설명회 명단 (전체 로스터)
    And [OWNER-F5-08] 명단 행 액션 (상태별) → 미예약 (재학생)
    Then [OWNER-F5-09] 상태 변화: none → reserved
    And 문자 발송: 예약 확정 + QR
    When [OWNER-F5-15] 명단 인쇄 → A4 로스터(체크·서명란) → 인쇄
    And [OWNER-F5-16] 설명회 종료 → 종료 처리
    Then [OWNER-F5-17] 상태 변화: reserved → no_show · Student.noShowCount++
    And 문자 발송: (선택) 종료 안내
    When [OWNER-F5-18] 설명회 삭제 → 삭제 확인
    Then [OWNER-F5-19] 상태 변화: -Session · -Reservation
    And 문자 발송: 취소 안내

  Scenario: OWNER-F5 · 설명회 운영 — QR 현황 대시보드 — 미입장 (reserved) / 종료 처리 / 삭제 확인
    Given [OWNER-F5-01] 설명회 운영 진입 + 좌측 설명회 선택
    When [OWNER-F5-02] 새 설명회 생성
    Then [OWNER-F5-03] 상태 변화: +Session
    When [OWNER-F5-04] 현황 헤더 + 스탯 5장
    And [OWNER-F5-05] 리마인드 스케줄 토글 / 지금 발송
    Then 문자 발송: 전일·당일 리마인드 (자동 배지)
    When [OWNER-F5-06] 설문 보내기 (입장>0)
    Then 문자 발송: 만족도 설문 링크
    When [OWNER-F5-07] 설명회 명단 (전체 로스터)
    And [OWNER-F5-08] 명단 행 액션 (상태별) → 미입장 (reserved)
    Then [OWNER-F5-10] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F5-15] 명단 인쇄 → A4 로스터(체크·서명란) → 인쇄
    And [OWNER-F5-16] 설명회 종료 → 종료 처리
    Then [OWNER-F5-17] 상태 변화: reserved → no_show · Student.noShowCount++
    And 문자 발송: (선택) 종료 안내
    When [OWNER-F5-18] 설명회 삭제 → 삭제 확인
    Then [OWNER-F5-19] 상태 변화: -Session · -Reservation
    And 문자 발송: 취소 안내

  Scenario: OWNER-F5 · 설명회 운영 — QR 현황 대시보드 — 입장 (entered) / 종료 처리 / 삭제 확인
    Given [OWNER-F5-01] 설명회 운영 진입 + 좌측 설명회 선택
    When [OWNER-F5-02] 새 설명회 생성
    Then [OWNER-F5-03] 상태 변화: +Session
    When [OWNER-F5-04] 현황 헤더 + 스탯 5장
    And [OWNER-F5-05] 리마인드 스케줄 토글 / 지금 발송
    Then 문자 발송: 전일·당일 리마인드 (자동 배지)
    When [OWNER-F5-06] 설문 보내기 (입장>0)
    Then 문자 발송: 만족도 설문 링크
    When [OWNER-F5-07] 설명회 명단 (전체 로스터)
    And [OWNER-F5-08] 명단 행 액션 (상태별) → 입장 (entered)
    And [OWNER-F5-11] 입장 취소 → 사유 선택
    Then [OWNER-F5-12] 상태 변화: entered → reserved · audit[]
    When [OWNER-F5-15] 명단 인쇄 → A4 로스터(체크·서명란) → 인쇄
    And [OWNER-F5-16] 설명회 종료 → 종료 처리
    Then [OWNER-F5-17] 상태 변화: reserved → no_show · Student.noShowCount++
    And 문자 발송: (선택) 종료 안내
    When [OWNER-F5-18] 설명회 삭제 → 삭제 확인
    Then [OWNER-F5-19] 상태 변화: -Session · -Reservation
    And 문자 발송: 취소 안내

  Scenario: OWNER-F5 · 설명회 운영 — QR 현황 대시보드 — 비재원생 / 종료 처리 / 삭제 확인
    Given [OWNER-F5-01] 설명회 운영 진입 + 좌측 설명회 선택
    When [OWNER-F5-02] 새 설명회 생성
    Then [OWNER-F5-03] 상태 변화: +Session
    When [OWNER-F5-04] 현황 헤더 + 스탯 5장
    And [OWNER-F5-05] 리마인드 스케줄 토글 / 지금 발송
    Then 문자 발송: 전일·당일 리마인드 (자동 배지)
    When [OWNER-F5-06] 설문 보내기 (입장>0)
    Then 문자 발송: 만족도 설문 링크
    When [OWNER-F5-07] 설명회 명단 (전체 로스터)
    And [OWNER-F5-08] 명단 행 액션 (상태별) → 비재원생
    And [OWNER-F5-13] 전환 → 반 배정(프리필)
    Then [OWNER-F5-14] 상태 변화: +Student · convertedFrom · 예약 연결
    And 문자 발송: 등록 환영
    When [OWNER-F5-15] 명단 인쇄 → A4 로스터(체크·서명란) → 인쇄
    And [OWNER-F5-16] 설명회 종료 → 종료 처리
    Then [OWNER-F5-17] 상태 변화: reserved → no_show · Student.noShowCount++
    And 문자 발송: (선택) 종료 안내
    When [OWNER-F5-18] 설명회 삭제 → 삭제 확인
    Then [OWNER-F5-19] 상태 변화: -Session · -Reservation
    And 문자 발송: 취소 안내

  # ===== OWNER-F6 · 상담 예약 (슬롯 그리드 · 신청 모니터링) =====

  Scenario: OWNER-F6 · 상담 예약
    Given [OWNER-F6-01] 상담 예약 진입
    When [OWNER-F6-02] 강사 필터로 슬롯·신청 슬라이스
    Then [OWNER-F6-03] 신청 모니터링

  # ===== OWNER-F7 · 통계 대시보드 (원장·실장 전용) =====

  Scenario: OWNER-F7 · 통계 대시보드
    Given [OWNER-F7-01] 통계 진입
    When [OWNER-F7-02] 지표 카드
    And [OWNER-F7-03] 차트

  # ===== OWNER-F8 · QR 스캐너 (태블릿) (현장 입장 처리) =====

  Scenario: OWNER-F8 · QR 스캐너 (태블릿) — ON — 이 기기로 스캔 / 인식 성공 / 재원생·기존 예약
    Given [OWNER-F8-01] 기기 모니터링 (최대 4대)
    When [OWNER-F8-02] 기기 선택 → ON — 이 기기로 스캔
    And [OWNER-F8-03] 전체화면 스캐너
    And [OWNER-F8-05] QR 인식 (데모) → 인식 성공
    Then [OWNER-F8-06] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F8-07] 현장 입장 (연락처 뒤 4자리) → 재원생·기존 예약
    Then [OWNER-F8-08] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료

  Scenario: OWNER-F8 · QR 스캐너 (태블릿) — OFF — 연결하기 / 인식 성공 / 재원생·기존 예약
    Given [OWNER-F8-01] 기기 모니터링 (최대 4대)
    When [OWNER-F8-02] 기기 선택 → OFF — 연결하기
    And [OWNER-F8-04] 카메라 권한(허용/거부)
    And [OWNER-F8-05] QR 인식 (데모) → 인식 성공
    Then [OWNER-F8-06] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F8-07] 현장 입장 (연락처 뒤 4자리) → 재원생·기존 예약
    Then [OWNER-F8-08] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료

  Scenario: OWNER-F8 · QR 스캐너 (태블릿) — ON — 이 기기로 스캔 / 인식 성공 / 재원생·무예약
    Given [OWNER-F8-01] 기기 모니터링 (최대 4대)
    When [OWNER-F8-02] 기기 선택 → ON — 이 기기로 스캔
    And [OWNER-F8-03] 전체화면 스캐너
    And [OWNER-F8-05] QR 인식 (데모) → 인식 성공
    Then [OWNER-F8-06] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F8-07] 현장 입장 (연락처 뒤 4자리) → 재원생·무예약
    Then [OWNER-F8-09] 상태 변화: → entered
    And 문자 발송: 입장 완료

  Scenario: OWNER-F8 · QR 스캐너 (태블릿) — OFF — 연결하기 / 인식 성공 / 재원생·무예약
    Given [OWNER-F8-01] 기기 모니터링 (최대 4대)
    When [OWNER-F8-02] 기기 선택 → OFF — 연결하기
    And [OWNER-F8-04] 카메라 권한(허용/거부)
    And [OWNER-F8-05] QR 인식 (데모) → 인식 성공
    Then [OWNER-F8-06] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F8-07] 현장 입장 (연락처 뒤 4자리) → 재원생·무예약
    Then [OWNER-F8-09] 상태 변화: → entered
    And 문자 발송: 입장 완료

  Scenario: OWNER-F8 · QR 스캐너 (태블릿) — ON — 이 기기로 스캔 / 인식 성공 / 비재원생
    Given [OWNER-F8-01] 기기 모니터링 (최대 4대)
    When [OWNER-F8-02] 기기 선택 → ON — 이 기기로 스캔
    And [OWNER-F8-03] 전체화면 스캐너
    And [OWNER-F8-05] QR 인식 (데모) → 인식 성공
    Then [OWNER-F8-06] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F8-07] 현장 입장 (연락처 뒤 4자리) → 비재원생
    And [OWNER-F8-10] 수동예약 등록 안내

  Scenario: OWNER-F8 · QR 스캐너 (태블릿) — OFF — 연결하기 / 인식 성공 / 비재원생
    Given [OWNER-F8-01] 기기 모니터링 (최대 4대)
    When [OWNER-F8-02] 기기 선택 → OFF — 연결하기
    And [OWNER-F8-04] 카메라 권한(허용/거부)
    And [OWNER-F8-05] QR 인식 (데모) → 인식 성공
    Then [OWNER-F8-06] 상태 변화: reserved → entered
    And 문자 발송: 입장 완료 안내
    When [OWNER-F8-07] 현장 입장 (연락처 뒤 4자리) → 비재원생
    And [OWNER-F8-10] 수동예약 등록 안내

  # ===== OWNER-F9 · 모바일 프리뷰 (테스트 전용) =====

  Scenario: OWNER-F9 · 모바일 프리뷰
    Given [OWNER-F9-01] 폰 프레임 안 MobileFlow 구동
    Then [OWNER-F9-02] 상태 변화: 프리뷰 예약이 store 즉시 반영
    When [OWNER-F9-03] 초기화 (플로우 처음으로)

