# 자동 생성 — 원본(진실원): flow-data.js / flows.json. 직접 수정하지 말고 원본에서 재생성.
# npr 입시설명회 운영 시스템 · 권한별 E2E 유저플로우

Feature: 강사 — 강의 · 현장 운영 지원 (=직원)
  목표: 현장 입장·예약·문자·상담 등 운영을 지원한다. 전체 명단·통계는 제외.
  진입: 로그인(강사) → 허브(재원생 관리·통계 잠금)
  권한: ✓ 설명회·전화·문자·상담·QR / ✕ 재원생 관리 / ✕ 통계
  참고: 강사(=직원)는 재원생 관리(전체 명단)·통계 대시보드만 접근 불가입니다. 그 외 전화예약·문자·설명회 운영·상담·QR 스캐너·프리뷰는 원장과 동일하게 보기+동작 가능 — 아래는 로그인/게이팅과 설명회 운영 델타만 표기하며, 나머지는 OWNER-F3·F4·F6·F8·F9를 그대로 따릅니다.

  # ===== GANGSA-F1 · 로그인 & 권한 게이팅 (강사(=직원)) =====

  Scenario: GANGSA-F1 · 로그인 & 권한 게이팅 — 허용
    Given [GANGSA-F1-01] 로그인 화면 → 강사 선택
    Then [GANGSA-F1-02] 상태 변화: npr-user = gangsa
    When [GANGSA-F1-03] 허브
    Then 권한 차단: 재원생 관리 · 통계 비활성
    When [GANGSA-F1-04] 접근 가능 모듈 → 허용
    And [GANGSA-F1-05] 전화예약·문자·설명회 운영·상담·QR 스캐너·프리뷰

  Scenario: GANGSA-F1 · 로그인 & 권한 게이팅 — 차단
    Given [GANGSA-F1-01] 로그인 화면 → 강사 선택
    Then [GANGSA-F1-02] 상태 변화: npr-user = gangsa
    When [GANGSA-F1-03] 허브
    Then 권한 차단: 재원생 관리 · 통계 비활성
    When [GANGSA-F1-04] 접근 가능 모듈 → 차단
    Then [GANGSA-F1-06] 권한 차단: 탭 미노출

  # ===== GANGSA-G1 · 차단 라우트 접근 시도 (권한 잠금 처리) =====

  Scenario: GANGSA-G1 · 차단 라우트 접근 시도
    Given [GANGSA-G1-01] 재원생 관리 / 통계 URL·라우트 직접 진입 시도
    Then [GANGSA-G1-02] 권한 차단: allowed 미포함
    And [GANGSA-G1-03] 상태 변화: route → hub

  # ===== GANGSA-F5 · 설명회 운영 (강사) (원장 F5와 동일 — 전 기능 수행) =====

  Scenario: GANGSA-F5 · 설명회 운영 (강사)
    Given [GANGSA-F5-01] QR 현황 대시보드
    When [GANGSA-F5-02] 즉석 예약 · 수동 체크인 · 입장 취소 · 전환 · 명단 인쇄 · 종료

