# 자동 생성 — 원본(진실원): flow-data.js / flows.json. 직접 수정하지 말고 원본에서 재생성.
# npr 입시설명회 운영 시스템 · 권한별 E2E 유저플로우

Feature: 학부모 / 학생 — 설명회 예약자 (모바일)
  목표: 자녀 설명회를 예약·관리하고 상담을 신청한다.
  진입: mobile.html — 로그인 없음
  권한: ✓ 모바일 예약 / ✕ 콘솔 접근 / ✕ 로그인

  # ===== PARENT-P1 · 설명회 선택 (모바일 · 로그인 없음) =====

  Scenario: PARENT-P1 · 설명회 선택 — 마감 (0석)
    Given [PARENT-P1-01] mobile.html 접속
    When [PARENT-P1-02] 설명회 목록
    And [PARENT-P1-03] 잔여석 상태 → 마감 (0석)
    Then [PARENT-P1-04] 카드 비활성 (선택 불가)

  Scenario: PARENT-P1 · 설명회 선택 — 임박 (≤15%)
    Given [PARENT-P1-01] mobile.html 접속
    When [PARENT-P1-02] 설명회 목록
    And [PARENT-P1-03] 잔여석 상태 → 임박 (≤15%)
    And [PARENT-P1-05] 경고 배지 표시 → 진행

  Scenario: PARENT-P1 · 설명회 선택 — 여유
    Given [PARENT-P1-01] mobile.html 접속
    When [PARENT-P1-02] 설명회 목록
    And [PARENT-P1-03] 잔여석 상태 → 여유
    And [PARENT-P1-06] → 재원생 예약 (P2)

  # ===== PARENT-P2 · 재원생 예약 (가족 포함) (단일·다중(형제)) =====

  Scenario: PARENT-P2 · 재원생 예약 (가족 포함) — 불일치
    Given [PARENT-P2-01] 재원생 예약 화면
    When [PARENT-P2-02] 학부모 연락처 입력 → 조회
    And [PARENT-P2-03] 일치 학생? → 불일치
    And [PARENT-P2-04] 에러 안내 → 비재원생 예약 유도 (P3)

  Scenario: PARENT-P2 · 재원생 예약 (가족 포함) — 일치 / true / 1명
    Given [PARENT-P2-01] 재원생 예약 화면
    When [PARENT-P2-02] 학부모 연락처 입력 → 조회
    And [PARENT-P2-03] 일치 학생? → 일치
    And [PARENT-P2-05] 학생 카드 다중 체크 선택 (최대 3, 형제)
    And [PARENT-P2-06] attendField? → true
    And [PARENT-P2-07] 자녀당 참석 인원 선택
    And [PARENT-P2-08] 하단 CTA → 1명
    Then [PARENT-P2-09] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR
    When [PARENT-P2-11] 예약 완료 티켓

  Scenario: PARENT-P2 · 재원생 예약 (가족 포함) — 일치 / true / N명
    Given [PARENT-P2-01] 재원생 예약 화면
    When [PARENT-P2-02] 학부모 연락처 입력 → 조회
    And [PARENT-P2-03] 일치 학생? → 일치
    And [PARENT-P2-05] 학생 카드 다중 체크 선택 (최대 3, 형제)
    And [PARENT-P2-06] attendField? → true
    And [PARENT-P2-07] 자녀당 참석 인원 선택
    And [PARENT-P2-08] 하단 CTA → N명
    Then [PARENT-P2-10] 상태 변화: +N Reservation · groupId
    And 문자 발송: 자녀별 개별 확정
    When [PARENT-P2-11] 예약 완료 티켓

  # ===== PARENT-P3 · 비재원생 예약 =====

  Scenario: PARENT-P3 · 비재원생 예약 — true
    Given [PARENT-P3-01] '비재원생 예약하기' 링크
    When [PARENT-P3-02] 폼: 이름*·학교·학년·연락처*
    And [PARENT-P3-03] attendField? → true
    And [PARENT-P3-04] 참석 인원 선택
    Then [PARENT-P3-05] 상태 변화: → reserved
    And 문자 발송: 예약 확정 + QR

  # ===== PARENT-P4 · 예약 조회 · 변경 · 취소 (셀프 관리) =====

  Scenario: PARENT-P4 · 예약 조회 · 변경 · 취소 — 불일치
    Given [PARENT-P4-01] 목록 하단 '예약 조회 · 변경 · 취소' 링크
    When [PARENT-P4-02] 예약 조회 (연락처 + 예약번호)
    And [PARENT-P4-03] 일치? → 불일치
    And [PARENT-P4-04] 에러 안내

  Scenario: PARENT-P4 · 예약 조회 · 변경 · 취소 — 일치 / 예약 변경
    Given [PARENT-P4-01] 목록 하단 '예약 조회 · 변경 · 취소' 링크
    When [PARENT-P4-02] 예약 조회 (연락처 + 예약번호)
    And [PARENT-P4-03] 일치? → 일치
    And [PARENT-P4-05] 내 예약 티켓 (상태·이력)
    And [PARENT-P4-06] 관리 선택 → 예약 변경
    And [PARENT-P4-07] 회차 선택 시트(잔여석)
    Then [PARENT-P4-08] 상태 변화: sessionId 이동 · history[]
    And 문자 발송: 변경 확정

  Scenario: PARENT-P4 · 예약 조회 · 변경 · 취소 — 일치 / 예약 취소
    Given [PARENT-P4-01] 목록 하단 '예약 조회 · 변경 · 취소' 링크
    When [PARENT-P4-02] 예약 조회 (연락처 + 예약번호)
    And [PARENT-P4-03] 일치? → 일치
    And [PARENT-P4-05] 내 예약 티켓 (상태·이력)
    And [PARENT-P4-06] 관리 선택 → 예약 취소
    And [PARENT-P4-09] 취소 확인 (시작 24h 전)
    Then [PARENT-P4-10] 상태 변화: → cancelled (by parent)
    And 문자 발송: 취소 확인

  # ===== PARENT-P5 · 상담 신청 =====

  Scenario: PARENT-P5 · 상담 신청
    Given [PARENT-P5-01] 예약 완료 화면 '개별 상담 신청'
    When [PARENT-P5-02] 슬롯 선택 (강사별 가능 시간)
    Then [PARENT-P5-03] 상태 변화: +CounselBooking
    And 문자 발송: 상담 확정 · 리마인드
    And [PARENT-P5-04] 신청 완료 → 콘솔 상담 목록 반영 (OWNER-F6)

  # ===== PARENT-P6 · 만족도 설문 =====

  Scenario: PARENT-P6 · 만족도 설문 — 가능
    Given [PARENT-P6-01] 목록 하단 '만족도 설문' 링크
    When [PARENT-P6-02] 별점(1~5) + 객관식 3문항 + 주관식 1
    And [PARENT-P6-03] 제출 가능? → 가능
    Then [PARENT-P6-04] 상태 변화: +SurveyResponse
    And [PARENT-P6-05] 감사 화면

