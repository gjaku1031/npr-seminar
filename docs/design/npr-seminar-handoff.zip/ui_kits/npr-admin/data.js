/* npr 입시설명회 운영 콘솔 — 샘플 데이터 (전부 가상) */
(function () {
  const lastNames = ['김', '이', '박', '최', '정', '한', '조', '윤', '장', '임'];
  const firstNames = ['수민', '서연', '지호', '하준', '은우', '지아', '도윤', '시우', '예린', '준서', '민재', '유나', '태윤', '가은', '현우', '소율', '재이', '다온', '루아', '건우'];
  const schools = { 초: ['가람초', '한빛초', '푸른초'], 중: ['가람중', '미림중', '동성중'], 고: ['한빛고', '세종고', '미림여고'] };
  const classes = [
    { id: 'e1', name: '초등부 A', level: '초', teacherId: 't4' },
    { id: 'm1', name: '중등부 A', level: '중', teacherId: 't1' },
    { id: 'm2', name: '중등부 B', level: '중', teacherId: 't2' },
    { id: 'h1', name: '고등부 A', level: '고', teacherId: 't3' },
    { id: 'h2', name: '고등부 B', level: '고', teacherId: 't2' },
  ];
  const teachers = [
    { id: 't1', name: '김지훈' },
    { id: 't2', name: '박세라' },
    { id: 't3', name: '이도현' },
    { id: 't4', name: '한유진' },
  ];

  const students = [];
  for (let i = 0; i < 40; i++) {
    const cls = classes[i % classes.length];
    const gradeNum = (i * 7) % (cls.level === '초' ? 6 : 3) + 1;
    const name = lastNames[(i * 3) % 10] + firstNames[(i * 11 + 4) % 20];
    const phone = `010-${String(3200 + i * 37).slice(-4)}-${String(6100 + i * 53).slice(-4)}`;
    students.push({
      id: 'stu' + (i + 1),
      name,
      school: schools[cls.level][(i * 5) % 3],
      grade: `${cls.level}${gradeNum}`,
      classId: cls.id,
      className: cls.name,
      parentPhone: phone,
    });
  }

  const sessions = [
    {
      id: 'ss1', title: '2027 대비 고등 입시전략 설명회', date: '7월 26일 (일)', round: '2회차', time: '14:00',
      place: 'npr 본관 5층 세미나홀', capacity: 120, desc: '고1·2 대상 수시/정시 전략과 npr 관리 시스템 소개.', attendField: true, active: true, ended: false,
      reminders: [
        { id: 'rm1', label: '전일 리마인드', time: 'D-1 18:00', template: '전일 리마인드', enabled: true },
        { id: 'rm2', label: '당일 리마인드', time: '당일 -2시간', template: '전일 리마인드', enabled: false },
      ],
    },
    {
      id: 'ss2', title: '중등 신입생 로드맵 설명회', date: '8월 1일 (토)', round: '1회차', time: '10:30',
      place: 'npr 본관 3층 강의실 A', capacity: 60, desc: '', attendField: false, active: true, ended: false,
      reminders: [
        { id: 'rm1', label: '전일 리마인드', time: 'D-1 18:00', template: '전일 리마인드', enabled: true },
        { id: 'rm2', label: '당일 리마인드', time: '당일 -2시간', template: '전일 리마인드', enabled: false },
      ],
    },
    {
      id: 'ss3', title: '초등 고학년 학습 설명회', date: '8월 8일 (토)', round: '1회차', time: '11:00',
      place: 'npr 별관 1층 홀', capacity: 40, desc: '초4~6 학부모 대상.', attendField: true, active: true, ended: false,
      reminders: [
        { id: 'rm1', label: '전일 리마인드', time: 'D-1 18:00', template: '전일 리마인드', enabled: true },
        { id: 'rm2', label: '당일 리마인드', time: '당일 -2시간', template: '전일 리마인드', enabled: false },
      ],
    },
  ];

  /* 예약: status reserved(미체크) | entered(입장 완료) | cancelled */
  const reservations = [];
  let rid = 1;
  const add = (sessionId, studentIdx, channel, status, attendCount) => {
    const st = students[studentIdx];
    reservations.push({
      id: 'r' + rid, code: `NPR-${sessionId.toUpperCase()}-${String(rid).padStart(4, '0')}`,
      sessionId, studentId: st.id, name: st.name, school: st.school, grade: st.grade,
      phone: st.parentPhone, channel, status, attendCount: attendCount || 1, member: true,
      time: `${9 + (rid % 9)}:${String((rid * 17) % 60).padStart(2, '0')}`,
    });
    rid++;
  };
  // ss1: 재원생 18명 (전화 6, 모바일 12), 입장 7, 취소 2
  for (let i = 0; i < 18; i++) add('ss1', i, i % 3 === 0 ? 'phone' : 'mobile', i < 7 ? 'entered' : i >= 16 ? 'cancelled' : 'reserved', 1 + (i % 3 === 1 ? 1 : 0));
  // ss1 비재원생 4명
  [['정하윤', '동성중', '중3', '010-7741-2210'], ['오지우', '세종고', '고1', '010-8852-3341'], ['남도현', '미림중', '중2', '010-6633-4472'], ['배서아', '한빛고', '고2', '010-5524-5583']].forEach((g, i) => {
    reservations.push({ id: 'r' + rid, code: `NPR-SS1-${String(rid).padStart(4, '0')}`, sessionId: 'ss1', studentId: null, name: g[0], school: g[1], grade: g[2], phone: g[3], channel: i % 2 ? 'mobile' : 'phone', status: i === 0 ? 'entered' : 'reserved', attendCount: 2, member: false, time: `1${i}:2${i}` });
    rid++;
  });
  // ss2: 재원생 9명
  for (let i = 20; i < 29; i++) add('ss2', i, i % 4 === 0 ? 'phone' : 'mobile', i < 23 ? 'entered' : 'reserved');
  // ss3: 6명
  for (let i = 30; i < 36; i++) add('ss3', i, 'mobile', 'reserved', 2);

  const smsTemplates = [
    { id: 'tp1', name: '예약 확정 + QR', body: '[npr] {학생명} 님, {설명회명} 예약이 확정되었습니다.\n일시: {일시}\n장소: {장소}\n아래 QR로 입장해 주세요.\n{QR링크}' },
    { id: 'tp2', name: '입장 완료 안내', body: '[npr] {학생명} 님이 {설명회명}에 입장 완료했습니다. 안심하고 기다려 주세요.' },
    { id: 'tp3', name: '전일 리마인드', body: '[npr] 내일은 {설명회명} 날이에요!\n{일시} · {장소}\nQR을 미리 준비해 주세요. 취소는 이 문자에 회신.' },
  ];

  const smsLogs = [
    { id: 'l1', when: '오늘 09:12', to: 214, template: '전일 리마인드', session: '2027 대비 고등 입시전략 설명회', ok: 212, fail: 2 },
    { id: 'l2', when: '어제 18:40', to: 96, template: '예약 확정 + QR', session: '중등 신입생 로드맵 설명회', ok: 96, fail: 0 },
    { id: 'l3', when: '7월 12일 11:05', to: 41, template: '예약 확정 + QR', session: '초등 고학년 학습 설명회', ok: 40, fail: 1 },
  ];

  const devices = [
    { id: 'd1', label: '입구 A', model: 'iPad Pro 11" (4th)', on: true, battery: 82, last: '방금 전' },
    { id: 'd2', label: '입구 B', model: 'iPad Air 5', on: true, battery: 64, last: '1분 전' },
    { id: 'd3', label: '별관 입구', model: 'Galaxy Tab S9', on: false, battery: 31, last: '43분 전' },
    { id: 'd4', label: '예비', model: 'iPad 9', on: false, battery: 100, last: '어제' },
  ];

  /* 만족도 설문 응답 시드 (종료된 회차 대상 · 별점 1~5 + 객관식 + 주관식) */
  const surveyResponses = [
    { id: 'sv1', sessionId: 'ss1', rating: 5, helpful: '매우 도움됨', again: '네', comment: '입시 전략이 구체적이라 좋았어요.' },
    { id: 'sv2', sessionId: 'ss1', rating: 4, helpful: '도움됨', again: '네', comment: '주차 안내가 조금 아쉬웠습니다.' },
    { id: 'sv3', sessionId: 'ss1', rating: 5, helpful: '매우 도움됨', again: '네', comment: '' },
    { id: 'sv4', sessionId: 'ss1', rating: 4, helpful: '도움됨', again: '보통', comment: '자료를 미리 받고 싶어요.' },
    { id: 'sv5', sessionId: 'ss1', rating: 3, helpful: '보통', again: '보통', comment: '' },
    { id: 'sv6', sessionId: 'ss1', rating: 5, helpful: '매우 도움됨', again: '네', comment: '상담 연계가 특히 유용했어요.' },
  ];

  /* 상담 슬롯 (강사 × 일시) + 신청 시드 */
  const counselSlots = [];
  let csid = 1;
  const cDays = ['7월 28일 (월)', '7월 29일 (화)'];
  const cTimes = ['15:00', '16:00', '17:00', '18:00'];
  ['t3', 't1', 't2'].forEach((tid) => { cDays.forEach((d) => { cTimes.forEach((tm) => { counselSlots.push({ id: 'cs' + (csid++), teacherId: tid, date: d, time: tm, booked: false }); }); }); });
  const counselBookings = [];
  [['cs1', '김수민', '고1', '010-3200-6100'], ['cs6', '이서연', '고2', '010-3459-6577'], ['cs14', '박도윤', '중3', '010-3644-6789']].forEach((b, i) => {
    const slot = counselSlots.find((s) => s.id === b[0]);
    if (slot) { slot.booked = true; counselBookings.push({ id: 'cb' + (i + 1), slotId: slot.id, teacherId: slot.teacherId, date: slot.date, time: slot.time, name: b[1], grade: b[2], phone: b[3], from: 'ss1' }); }
  });

  window.NPR_DATA = { teachers, classes, students, sessions, reservations, smsTemplates, smsLogs, devices, surveyResponses, counselSlots, counselBookings };
})();
