/* 통계 대시보드 — 예약·참석·노쇼·전환 지표 + 회차별/채널/시간대 차트 */
function StatsScreen({ store }) {
  const { Card, Badge } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { sessions, reservations, students, surveyResponses, counselBookings } = store;

  const active = reservations.filter((r) => r.status !== 'cancelled');
  const entered = active.filter((r) => r.status === 'entered');
  const noShow = active.filter((r) => r.status === 'no_show');
  const guests = active.filter((r) => !r.member);
  const converted = students.filter((s) => s.convertedFrom);

  const attendRate = active.length ? Math.round((entered.length / active.length) * 100) : 0;
  const noShowRate = active.length ? Math.round((noShow.length / active.length) * 100) : 0;
  const convRate = guests.length ? Math.round((converted.length / guests.length) * 100) : 0;

  /* 채널 분포 */
  const chData = [
    { key: 'mobile', label: '모바일', color: 'var(--violet-600)', n: active.filter((r) => r.channel === 'mobile').length },
    { key: 'phone', label: '전화', color: 'var(--mint-500)', n: active.filter((r) => r.channel === 'phone').length },
    { key: 'manual', label: '수동', color: 'var(--violet-300)', n: active.filter((r) => r.channel === 'manual').length },
  ];
  const chTotal = chData.reduce((a, b) => a + b.n, 0) || 1;
  let acc = 0;
  const stops = chData.map((c) => { const from = acc / chTotal * 360; acc += c.n; const to = acc / chTotal * 360; return `${c.color} ${from}deg ${to}deg`; }).join(', ');

  /* 시간대 추이 (예약 생성 시각 기준) */
  const hours = [9, 10, 11, 12, 13, 14, 15, 16, 17, 18];
  const byHour = hours.map((h) => active.filter((r) => parseInt(r.time, 10) === h).length);
  const maxHour = Math.max(...byHour, 1);
  const W = 620, H = 150, padX = 10, padY = 14;
  const pts = byHour.map((v, i) => {
    const x = padX + (i / (hours.length - 1)) * (W - padX * 2);
    const y = padY + (1 - v / maxHour) * (H - padY * 2);
    return [x, y];
  });
  const linePath = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const areaPath = `${linePath} L ${pts[pts.length - 1][0].toFixed(1)} ${H - padY} L ${pts[0][0].toFixed(1)} ${H - padY} Z`;

  const avgRating = surveyResponses && surveyResponses.length ? (surveyResponses.reduce((a, b) => a + b.rating, 0) / surveyResponses.length) : 0;

  return (
    <div data-screen-label="통계 대시보드">
      <div style={{ animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)', marginBottom: 6 }}>ANALYTICS</div>
        <h1 style={{ fontSize: 'var(--text-h1)', fontWeight: 800 }}>운영 통계</h1>
      </div>

      {/* 지표 카드 */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginTop: 20 }}>
        <StatCard label="누적 예약" value={active.length} suffix="건" tone="brand" icon={<I.ticket size={15} />} delay={0} />
        <StatCard label="참석률" value={attendRate} suffix="%" tone="success" icon={<I.userCheck size={15} />} delay={60} />
        <StatCard label="노쇼율" value={noShowRate} suffix="%" tone="neutral" icon={<I.alertTriangle size={15} />} delay={120} />
        <StatCard label="비재원 전환율" value={convRate} suffix="%" tone="accent" icon={<I.trendingUp size={15} />} delay={180} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14, marginTop: 14, alignItems: 'start' }}>
        {/* 회차별 참석률 */}
        <Card padding="20px 22px" style={{ animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 200ms both' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <I.barChart size={16} style={{ color: 'var(--violet-800)' }} />
            <span style={{ fontSize: 14.5, fontWeight: 700, color: 'var(--text-strong)' }}>회차별 참석률</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {sessions.map((s) => {
              const srs = reservations.filter((r) => r.sessionId === s.id && r.status !== 'cancelled');
              const se = srs.filter((r) => r.status === 'entered').length;
              const rate = srs.length ? Math.round((se / srs.length) * 100) : 0;
              return (
                <div key={s.id}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-strong)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 320 }}>{s.title}</span>
                    <span style={{ fontSize: 13, fontWeight: 800, color: 'var(--violet-800)', fontFeatureSettings: '"tnum"', flexShrink: 0, marginLeft: 10 }}>{rate}% <span style={{ fontSize: 11, color: 'var(--text-faint)', fontWeight: 500 }}>({se}/{srs.length})</span></span>
                  </div>
                  <span style={{ display: 'block', height: 10, borderRadius: 5, background: 'var(--gray-2)', overflow: 'hidden' }}>
                    <span style={{ display: 'block', height: '100%', width: `${rate}%`, borderRadius: 5, background: 'linear-gradient(90deg, var(--violet-600), var(--mint-500))', transition: 'width var(--dur-hero) var(--ease-smooth)' }}></span>
                  </span>
                </div>
              );
            })}
          </div>
        </Card>

        {/* 채널별 도넛 */}
        <Card padding="20px 22px" style={{ animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 260ms both' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <I.pieChart size={16} style={{ color: 'var(--mint-600)' }} />
            <span style={{ fontSize: 14.5, fontWeight: 700, color: 'var(--text-strong)' }}>채널별 예약</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div style={{ width: 120, height: 120, borderRadius: '50%', background: `conic-gradient(${stops})`, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              <div style={{ width: 74, height: 74, borderRadius: '50%', background: 'var(--surface-card)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 21, color: 'var(--text-strong)', fontFeatureSettings: '"tnum"', lineHeight: 1, whiteSpace: 'nowrap' }}>{chTotal}</span>
                <span style={{ fontSize: 10, color: 'var(--text-faint)', marginTop: 2 }}>건</span>
              </div>
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 9 }}>
              {chData.map((c) => (
                <div key={c.key} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 10, height: 10, borderRadius: 3, background: c.color, flexShrink: 0 }}></span>
                  <span style={{ fontSize: 13, color: 'var(--text-body)', flex: 1 }}>{c.label}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-strong)', fontFeatureSettings: '"tnum"' }}>{c.n}</span>
                  <span style={{ fontSize: 11.5, color: 'var(--text-faint)', width: 34, textAlign: 'right', fontFeatureSettings: '"tnum"' }}>{Math.round(c.n / chTotal * 100)}%</span>
                </div>
              ))}
            </div>
          </div>
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: '1px solid var(--border-hairline)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ display: 'flex', gap: 1 }}>{[1, 2, 3, 4, 5].map((n) => <I.star key={n} size={13} style={{ color: n <= Math.round(avgRating) ? 'var(--mint-500)' : 'var(--gray-3)', fill: n <= Math.round(avgRating) ? 'var(--mint-500)' : 'none' }} />)}</div>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>평균 만족도 <b style={{ color: 'var(--text-strong)' }}>{avgRating.toFixed(1)}</b></span>
            <span style={{ flex: 1 }}></span>
            <Badge tone="info" size="sm">상담 {(counselBookings || []).length}건</Badge>
          </div>
        </Card>
      </div>

      {/* 시간대 추이 */}
      <Card padding="20px 22px" style={{ marginTop: 14, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 320ms both' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
          <I.trendingUp size={16} style={{ color: 'var(--violet-800)' }} />
          <span style={{ fontSize: 14.5, fontWeight: 700, color: 'var(--text-strong)' }}>시간대별 예약 접수</span>
        </div>
        <svg viewBox={`0 0 ${W} ${H + 22}`} style={{ width: '100%', height: 'auto', display: 'block' }} data-om-raster>
          <defs>
            <linearGradient id="npr-area" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--violet-600)" stopOpacity="0.28" />
              <stop offset="100%" stopColor="var(--violet-600)" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={areaPath} fill="url(#npr-area)" />
          <path d={linePath} fill="none" stroke="var(--violet-700)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          {pts.map((p, i) => (
            <g key={i}>
              <circle cx={p[0]} cy={p[1]} r="3.5" fill="var(--surface-card)" stroke="var(--violet-700)" strokeWidth="2" />
              <text x={p[0]} y={H + 14} textAnchor="middle" fontSize="10.5" fill="var(--text-faint)" fontFamily="var(--font-body)">{hours[i]}시</text>
            </g>
          ))}
        </svg>
      </Card>
    </div>
  );
}
window.StatsScreen = StatsScreen;
