/* 모바일예약 프리뷰 — 시연용 학부모 뷰 (테스트 전용) */
function PreviewScreen({ store }) {
  const { Button, Badge } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const [resetKey, setResetKey] = React.useState(0);

  return (
    <div data-screen-label="모바일예약 프리뷰" style={{ display: 'flex', flexDirection: 'column', minHeight: 'calc(100vh - 92px)' }}>
      {/* 상단 바 */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 16, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div>
          <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)', marginBottom: 6 }}>MOBILE PREVIEW</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <h1 style={{ fontSize: 'var(--text-h1)', fontWeight: 800 }}>모바일예약 프리뷰</h1>
            <Badge tone="accent" dot>테스트 전용</Badge>
            <Badge tone="info">실제 문자 미발송</Badge>
          </div>
        </div>
        <Button variant="secondary" icon={<I.refresh size={15} />} onClick={() => setResetKey(resetKey + 1)}>프리뷰 초기화</Button>
      </div>

      {/* 정중앙 폰 프레임 */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '28px 0 12px', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 150ms both' }}>
        <div style={{ width: 370, borderRadius: 52, background: 'var(--violet-950)', padding: 11, boxShadow: 'var(--shadow-float)' }}>
          <div style={{ position: 'relative', borderRadius: 42, overflow: 'hidden', background: 'var(--surface-page)', width: 348, height: 754 }}>
            <div style={{ position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)', width: 110, height: 26, borderRadius: 16, background: 'var(--violet-950)', zIndex: 20 }}></div>
            <div key={resetKey} style={{ position: 'absolute', inset: 0, overflowY: 'auto', paddingTop: 40 }}>
              <MobileFlow store={store} compact />
            </div>
          </div>
        </div>
        <div style={{ textAlign: 'center', fontSize: 12.5, color: 'var(--text-faint)', marginTop: 12, lineHeight: 1.7 }}>
          여기서 만든 예약은 콘솔 데이터에 즉시 반영 · 재원생 조회는 명단 번호 일부(예: 3200)로 검색<br />
          실기기 화면은 사이드바의 <b style={{ color: 'var(--text-muted)' }}>모바일 예약 페이지 열기</b>
        </div>
      </div>
    </div>
  );
}
window.PreviewScreen = PreviewScreen;
