/* 운영 콘솔 로그인 — 역할 선택 (데모) */
function LoginScreen({ onLogin, teachers }) {
  const { Button, Select } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const [role, setRole] = React.useState(null);
  const [tid, setTid] = React.useState(teachers[0].id);

  const roles = [
    { key: 'owner', label: '원장', desc: '전체 기능 · 통계까지 접근', icon: <I.graduationCap size={20} /> },
    { key: 'siljang', label: '실장', desc: '원장과 동일 · 전체 권한', icon: <I.userCheck size={20} /> },
    { key: 'gangsa', label: '강사', desc: '재원생 관리·통계 제외 전체', icon: <I.users size={20} /> },
  ];

  const enter = () => {
    if (role === 'gangsa') { const t = teachers.find((x) => x.id === tid); onLogin({ role: 'gangsa', name: t.name, teacherId: t.id }); }
    else onLogin({ role, name: role === 'owner' ? '원장' : '실장' });
  };

  return (
    <div data-screen-label="운영 콘솔 로그인" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ width: '100%', maxWidth: 430, background: 'var(--surface-card)', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-float)', padding: '38px 36px 32px', animation: 'ds-pop var(--dur-slow) var(--ease-spring) both' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 34, height: 34, borderRadius: 10, background: 'var(--violet-800)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13 }}>npr</span>
          <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--violet-900)', letterSpacing: '-0.02em' }}>입시설명회</span>
        </div>
        <h1 style={{ fontSize: 22, fontWeight: 800, marginTop: 22, letterSpacing: 'var(--tracking-heading)' }}>운영 콘솔 로그인</h1>
        <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6, lineHeight: 1.55 }}>역할에 따라 접근할 수 있는 기능이 달라져요.<br /><span style={{ color: 'var(--text-faint)' }}>데모 — 역할을 선택해 입장하세요.</span></p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 22 }}>
          {roles.map((r) => {
            const sel = role === r.key;
            return (
              <div key={r.key} onClick={() => setRole(r.key)} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '14px 16px', borderRadius: 'var(--radius-lg)', cursor: 'pointer', background: sel ? 'var(--surface-brand-soft)' : 'var(--surface-card)', border: sel ? '1.5px solid var(--violet-800)' : '1px solid var(--border-hairline)', boxShadow: sel ? 'var(--shadow-accent-glow)' : 'var(--shadow-card)', transition: 'all var(--dur-fast) var(--ease-out)' }}>
                <span style={{ width: 42, height: 42, borderRadius: 'var(--radius-sm)', background: sel ? 'var(--violet-800)' : 'var(--violet-50)', color: sel ? '#fff' : 'var(--violet-800)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all var(--dur-fast) var(--ease-out)' }}>{r.icon}</span>
                <span style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--text-strong)' }}>{r.label}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>{r.desc}</div>
                </span>
                <span style={{ width: 22, height: 22, borderRadius: '50%', border: sel ? '7px solid var(--violet-900)' : '1.5px solid var(--border-soft)', transition: 'all var(--dur-fast) var(--ease-spring)', boxSizing: 'border-box', flexShrink: 0 }}></span>
              </div>
            );
          })}
        </div>

        {role === 'gangsa' && (
          <div style={{ marginTop: 14, animation: 'ds-fade-up var(--dur-base) var(--ease-out) both' }}>
            <Select label="강사 선택" options={teachers.map((t) => ({ label: t.name + ' 강사', value: t.id }))} value={tid} onChange={setTid} />
          </div>
        )}

        <Button size="lg" fullWidth disabled={!role} onClick={enter} iconRight={<I.arrowRight size={17} />} style={{ marginTop: 22 }}>입장하기</Button>
      </div>
    </div>
  );
}
window.LoginScreen = LoginScreen;
