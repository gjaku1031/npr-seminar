/* 상담 예약 — 설명회 → 개별 상담 전환. 슬롯 그리드(강사×일시) + 신청 목록 */
function CounselScreen({ store }) {
  const { Card, Badge, Tag } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { counselSlots, counselBookings, teachers } = store;

  const [teacherFilter, setTeacherFilter] = React.useState('all');
  const bookingOf = (slotId) => counselBookings.find((b) => b.slotId === slotId);
  const tName = (id) => (teachers.find((t) => t.id === id) || {}).name || '';

  const usedTeacherIds = [...new Set(counselSlots.map((s) => s.teacherId))];
  const shownTeachers = teacherFilter === 'all' ? usedTeacherIds : [teacherFilter];
  const days = [...new Set(counselSlots.map((s) => s.date))];

  const total = counselSlots.length;
  const booked = counselSlots.filter((s) => s.booked).length;

  return (
    <div data-screen-label="상담 예약">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div>
          <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)', marginBottom: 6 }}>COUNSELING</div>
          <h1 style={{ fontSize: 'var(--text-h1)', fontWeight: 800 }}>상담 예약</h1>
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <Tag selected={teacherFilter === 'all'} onClick={() => setTeacherFilter('all')} style={{ height: 32 }}>전체</Tag>
          {usedTeacherIds.map((tid) => <Tag key={tid} selected={teacherFilter === tid} onClick={() => setTeacherFilter(tid)} style={{ height: 32 }}>{tName(tid)}</Tag>)}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginTop: 20 }}>
        <StatCard label="전체 슬롯" value={total} suffix="개" tone="brand" icon={<I.calendar size={15} />} delay={0} />
        <StatCard label="예약 완료" value={booked} suffix="건" tone="success" icon={<I.userCheck size={15} />} delay={60} />
        <StatCard label="잔여 슬롯" value={total - booked} suffix="개" tone="accent" icon={<I.clock size={15} />} delay={120} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 14, marginTop: 14, alignItems: 'start' }}>
        {/* 슬롯 그리드 */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {shownTeachers.map((tid, ti) => (
            <Card key={tid} padding="18px 20px" style={{ animation: `ds-fade-up var(--dur-slow) var(--ease-out) ${ti * 70}ms both` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
                <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--text-strong)' }}>{tName(tid)} 강사</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: `repeat(${days.length}, 1fr)`, gap: 12 }}>
                {days.map((d) => (
                  <div key={d}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8 }}>{d}</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
                      {counselSlots.filter((s) => s.teacherId === tid && s.date === d).map((s) => {
                        const b = bookingOf(s.id);
                        return (
                          <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 11px', borderRadius: 'var(--radius-sm)', background: s.booked ? 'var(--surface-brand-soft)' : 'var(--surface-card)', border: s.booked ? '1px solid var(--violet-800)' : '1px dashed var(--border-soft)' }}>
                            <span style={{ fontSize: 12.5, fontWeight: 700, color: s.booked ? 'var(--violet-800)' : 'var(--text-muted)', fontFeatureSettings: '"tnum"' }}>{s.time}</span>
                            <span style={{ flex: 1 }}></span>
                            {s.booked ? <span style={{ fontSize: 12, color: 'var(--text-strong)', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 62 }}>{b ? b.name : '예약'}</span> : <span style={{ fontSize: 11, color: 'var(--text-faint)' }}>가능</span>}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>

        {/* 신청 목록 */}
        <Card padding="0" style={{ overflow: 'hidden', position: 'sticky', top: 20, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 160ms both' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '13px 18px', borderBottom: '1px solid var(--border-hairline)' }}>
            <I.clipboard size={15} style={{ color: 'var(--violet-800)' }} />
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>상담 신청</span>
            <span style={{ fontSize: 12.5, color: 'var(--text-faint)', fontFeatureSettings: '"tnum"' }}>{counselBookings.length}건</span>
          </div>
          {counselBookings.map((b, i) => (
            <div key={b.id} style={{ padding: '13px 18px', borderTop: i > 0 ? '1px solid var(--border-hairline)' : 'none', animation: `ds-fade-up var(--dur-base) var(--ease-out) ${Math.min(i, 8) * 40}ms both` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>{b.name}</span>
                <span style={{ fontSize: 12, color: 'var(--text-faint)' }}>{b.grade}</span>
                <span style={{ flex: 1 }}></span>
                <Badge tone="brand" size="sm">{tName(b.teacherId)}</Badge>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 6, fontSize: 12, color: 'var(--text-muted)', fontFeatureSettings: '"tnum"' }}>
                <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}><I.calendar size={12} />{b.date} {b.time}</span>
                <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}><I.phone size={12} />{b.phone}</span>
              </div>
            </div>
          ))}
          {counselBookings.length === 0 && <EmptyState>아직 상담 신청이 없어요.</EmptyState>}
        </Card>
      </div>
    </div>
  );
}
window.CounselScreen = CounselScreen;
