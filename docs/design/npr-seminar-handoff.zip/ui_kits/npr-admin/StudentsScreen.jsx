/* 재원생 관리 — 명단 + 필터 + 강사별 예약/입장 모니터링 */
function StudentsScreen({ store }) {
  const { Button, Input, Select, Tag, Card, Badge, Dialog, Toast } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { students, classes, sessions, reservations, addStudent } = store;

  const [q, setQ] = React.useState('');
  const [level, setLevel] = React.useState('전체');
  const [resFilter, setResFilter] = React.useState('전체');
  const [sessionId, setSessionId] = React.useState(sessions[0]?.id);
  const [addOpen, setAddOpen] = React.useState(false);
  const [excelOpen, setExcelOpen] = React.useState(false);
  const [uploadOpen, setUploadOpen] = React.useState(false);
  const [form, setForm] = React.useState({ name: '', school: '', grade: '', classId: classes[0].id, parentPhone: '' });
  const [toast, setToast] = React.useState(null);

  const uploadRows = [
    { name: '서지안', school: '가람중', grade: '중2', cls: '중등부 A', phone: '010-5521-7788', dup: false },
    { name: '문하준', school: '한빛고', grade: '고1', cls: '고등부 A', phone: '010-6642-1193', dup: false },
    { name: '김수민', school: '가람초', grade: '초4', cls: '초등부 A', phone: '010-3200-6100', dup: true },
    { name: '이레아', school: '미림중', grade: '중3', cls: '중등부 B', phone: '010-7781-4420', dup: false },
  ];
  const flash = (m) => { setToast(m); setTimeout(() => setToast(null), 3200); };

  const resOf = (stuId) => reservations.find((r) => r.sessionId === sessionId && r.studentId === stuId && r.status !== 'cancelled');

  const list = students.filter((s) => {
    const cls = classes.find((c) => c.id === s.classId);
    if (level !== '전체' && cls.level !== level) return false;
    if (q && !(s.name + s.school + s.parentPhone).includes(q)) return false;
    const r = resOf(s.id);
    if (resFilter === '예약' && !r) return false;
    if (resFilter === '입장' && (!r || r.status !== 'entered')) return false;
    if (resFilter === '미예약' && r) return false;
    return true;
  });

  const submitAdd = () => {
    if (!form.name || !form.parentPhone) return;
    const cls = classes.find((c) => c.id === form.classId);
    addStudent({ ...form, className: cls.name });
    setAddOpen(false);
    setForm({ name: '', school: '', grade: '', classId: classes[0].id, parentPhone: '' });
    setToast(`${form.name} 학생이 명단에 추가됐어요`);
    setTimeout(() => setToast(null), 3000);
  };
  const submitUpload = () => {
    const fresh = uploadRows.filter((r) => !r.dup);
    fresh.forEach((r) => { const cls = classes.find((c) => c.name === r.cls) || classes[0]; addStudent({ name: r.name, school: r.school, grade: r.grade, classId: cls.id, className: cls.name, parentPhone: r.phone }); });
    setUploadOpen(false);
    flash(`엑셀 ${uploadRows.length}행 반영 · 신규 ${fresh.length}명 추가 · 중복 ${uploadRows.length - fresh.length}건 병합`);
  };
  const doDownload = () => { setExcelOpen(false); flash(`현재 명단 ${list.length}명을 엑셀(.xlsx)로 내려받았어요`); };

  return (
    <div data-screen-label="재원생 관리">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div>
          <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)', marginBottom: 6 }}>STUDENTS</div>
          <h1 style={{ fontSize: 'var(--text-h1)', fontWeight: 800, whiteSpace: 'nowrap' }}>재원생 명단 <span style={{ fontSize: 17, color: 'var(--text-muted)', fontWeight: 600, whiteSpace: 'nowrap' }}>· {students.length}명</span></h1>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{ position: 'relative' }}>
              <Button variant="secondary" icon={<I.fileText size={16} />} iconRight={<I.chevronDown size={14} />} onClick={() => setExcelOpen((o) => !o)}>엑셀</Button>
              {excelOpen && (
                <React.Fragment>
                  <div onClick={() => setExcelOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 90 }}></div>
                  <div style={{ position: 'absolute', top: 44, right: 0, width: 200, background: 'var(--surface-card)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-float)', border: '1px solid var(--border-hairline)', overflow: 'hidden', zIndex: 91, animation: 'ds-fade-up var(--dur-fast) var(--ease-out) both' }}>
                    <button onClick={() => { setExcelOpen(false); setUploadOpen(true); }} style={{ display: 'flex', alignItems: 'center', gap: 9, width: '100%', padding: '11px 15px', background: 'none', border: 'none', cursor: 'pointer', fontSize: 13.5, color: 'var(--text-body)', fontFamily: 'var(--font-body)', textAlign: 'left' }}><I.upload size={15} /> 엑셀 업로드</button>
                    <button onClick={doDownload} style={{ display: 'flex', alignItems: 'center', gap: 9, width: '100%', padding: '11px 15px', background: 'none', border: 'none', borderTop: '1px solid var(--border-hairline)', cursor: 'pointer', fontSize: 13.5, color: 'var(--text-body)', fontFamily: 'var(--font-body)', textAlign: 'left' }}><I.download size={15} /> 명단 다운로드</button>
                  </div>
                </React.Fragment>
              )}
            </div>
            <Button icon={<I.plus size={16} />} onClick={() => setAddOpen(true)}>학생 추가</Button>
          </div>
      </div>

      {/* 필터 바 */}
      <Card padding="16px 18px" style={{ marginTop: 20, display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 80ms both' }}>
        <Input placeholder="이름·학교·연락처 검색" value={q} onChange={setQ} icon={<I.search size={16} />} style={{ width: 220 }} />
        <div style={{ display: 'flex', gap: 6 }}>
          {['전체', '초', '중', '고'].map((l) => <Tag key={l} selected={level === l} onClick={() => setLevel(l)}>{l === '전체' ? '전체' : l + '등부'}</Tag>)}
        </div>
        <span style={{ flex: 1 }}></span>
        <Select options={sessions.map((s) => ({ label: s.title, value: s.id }))} value={sessionId} onChange={setSessionId} style={{ width: 250 }} />
        <div style={{ display: 'flex', gap: 6 }}>
          {['전체', '예약', '입장', '미예약'].map((f) => <Tag key={f} selected={resFilter === f} onClick={() => setResFilter(f)}>{f}</Tag>)}
        </div>
      </Card>

      {/* 명단 테이블 */}
      <Card padding="0" style={{ marginTop: 14, overflow: 'hidden', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 160ms both' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr 0.6fr 0.9fr 1.2fr 0.8fr 0.8fr 0.7fr', padding: '11px 22px', background: 'var(--surface-sunken)', fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)', letterSpacing: '0.02em' }}>
          <span>학생 이름</span><span>학교</span><span>학년</span><span>반</span><span>학부모 연락처</span><span>예약</span><span>입장</span><span>노쇼</span>
        </div>
        {list.map((s, i) => {
          const r = resOf(s.id);
          return (
            <div key={s.id} style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr 0.6fr 0.9fr 1.2fr 0.8fr 0.8fr 0.7fr', alignItems: 'center', padding: '12px 22px', borderTop: '1px solid var(--border-hairline)', fontSize: 13.5, color: 'var(--text-body)', background: 'var(--surface-card)', animation: `ds-fade-up var(--dur-base) var(--ease-out) ${Math.min(i, 12) * 35}ms both` }}>
              <span style={{ fontWeight: 700, color: 'var(--text-strong)', display: 'flex', alignItems: 'center', gap: 6 }}>{s.name}{s.convertedFrom && <Badge tone="accent" size="sm">전환</Badge>}</span>
              <span>{s.school}</span>
              <span>{s.grade}</span>
              <span>{s.className}</span>
              <span style={{ fontFeatureSettings: '"tnum"' }}>{s.parentPhone}</span>
              <span>{r ? <Badge tone="brand" size="sm">예약됨</Badge> : <Badge tone="neutral" size="sm">미예약</Badge>}</span>
              <span>{r && r.status === 'entered' ? <Badge tone="success" dot size="sm">입장</Badge> : r ? <Badge tone="warning" size="sm">대기</Badge> : <span style={{ color: 'var(--text-faint)', fontSize: 12 }}>—</span>}</span>
              <span>{s.noShowCount ? <Badge tone="warning" size="sm">{s.noShowCount}회</Badge> : <span style={{ color: 'var(--text-faint)', fontSize: 12 }}>—</span>}</span>
            </div>
          );
        })}
        {list.length === 0 && <EmptyState>조건에 맞는 재원생이 없어요. 필터를 바꿔보세요.</EmptyState>}
      </Card>

      {/* 학생 추가 모달 */}
      <Dialog open={addOpen} onClose={() => setAddOpen(false)} title="학생 추가" width={460}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setAddOpen(false)}>취소</Button><Button disabled={!form.name || !form.parentPhone} onClick={submitAdd} icon={<I.plus size={15} />}>추가하기</Button></React.Fragment>}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input label="학생 이름" placeholder="김수민" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="학교" placeholder="가람중" value={form.school} onChange={(v) => setForm({ ...form, school: v })} />
            <Input label="학년" placeholder="중2" value={form.grade} onChange={(v) => setForm({ ...form, grade: v })} />
          </div>
          <Select label="반" options={classes.map((c) => ({ label: c.name, value: c.id }))} value={form.classId} onChange={(v) => setForm({ ...form, classId: v })} />
          <Input label="학부모 연락처" placeholder="010-0000-0000" value={form.parentPhone} onChange={(v) => setForm({ ...form, parentPhone: v })} hint="예약 조회·문자 발송에 사용돼요" />
        </div>
      </Dialog>

      {/* 엑셀 업로드 — 매핑 미리보기 (목업) */}
      <Dialog open={uploadOpen} onClose={() => setUploadOpen(false)} title="엑셀 업로드 — 매핑 미리보기" width={620}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setUploadOpen(false)}>취소</Button><Button onClick={submitUpload} icon={<I.check size={15} />}>반영하기</Button></React.Fragment>}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', borderRadius: 'var(--radius-md)', background: 'var(--surface-sunken)', fontSize: 13, color: 'var(--text-muted)' }}>
            <I.fileText size={16} style={{ color: 'var(--violet-800)', flexShrink: 0 }} />
            <span><b style={{ color: 'var(--text-strong)' }}>재원생_명단.xlsx</b> · {uploadRows.length}행 인식됨 · 열 매핑: 이름 · 학교 · 학년 · 반 · 연락처</span>
          </div>
          <div style={{ borderRadius: 'var(--radius-md)', border: '1px solid var(--border-hairline)', overflow: 'hidden' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 0.6fr 1fr 1.3fr', padding: '9px 14px', background: 'var(--surface-sunken)', fontSize: 11.5, fontWeight: 700, color: 'var(--text-muted)' }}>
              <span>이름</span><span>학교</span><span>학년</span><span>반</span><span>연락처</span>
            </div>
            {uploadRows.map((r, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 0.6fr 1fr 1.3fr', padding: '10px 14px', borderTop: '1px solid var(--border-hairline)', fontSize: 13, color: 'var(--text-body)', background: r.dup ? 'var(--status-warning-soft)' : 'var(--surface-card)', alignItems: 'center' }}>
                <span style={{ fontWeight: 700, color: 'var(--text-strong)' }}>{r.name}</span>
                <span>{r.school}</span>
                <span>{r.grade}</span>
                <span>{r.cls}</span>
                <span style={{ fontFeatureSettings: '"tnum"', display: 'flex', alignItems: 'center', gap: 6 }}>{r.phone}{r.dup && <Badge tone="warning" size="sm">중복·병합</Badge>}</span>
              </div>
            ))}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-faint)' }}>연락처가 같은 행은 기존 재원생과 병합돼요. 신규 {uploadRows.filter((r) => !r.dup).length}명이 명단에 추가됩니다.</div>
        </div>
      </Dialog>

      {toast && <div style={{ position: 'fixed', bottom: 26, left: '50%', transform: 'translateX(-50%)', zIndex: 120 }}><Toast tone="success">{toast}</Toast></div>}
    </div>
  );
}
window.StudentsScreen = StudentsScreen;