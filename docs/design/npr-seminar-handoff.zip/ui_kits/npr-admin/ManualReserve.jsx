/* 수동예약 등록 모달 — 재원생(연락처 조회) / 비재원생(직접 입력) */
function ManualReserveDialog({ open, onClose, session, students, reservations, addReservation, onDone }) {
  const { Dialog, Tabs, Input, Button, Select, Card, Badge } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const [tab, setTab] = React.useState('member');
  const [phone, setPhone] = React.useState('');
  const [searched, setSearched] = React.useState(null);
  const [picked, setPicked] = React.useState(null);
  const [attend, setAttend] = React.useState('1명');
  const [guest, setGuest] = React.useState({ name: '', school: '', grade: '', phone: '' });

  React.useEffect(() => { if (!open) { setPhone(''); setSearched(null); setPicked(null); setGuest({ name: '', school: '', grade: '', phone: '' }); setTab('member'); setAttend('1명'); } }, [open]);

  const already = (stuId) => reservations.some((r) => r.sessionId === session.id && r.studentId === stuId && r.status !== 'cancelled');
  const search = () => {
    const digits = phone.replace(/\D/g, '');
    setPicked(null);
    setSearched(digits.length < 4 ? [] : students.filter((s) => s.parentPhone.replace(/\D/g, '').includes(digits)));
  };

  const submit = () => {
    const attendCount = parseInt(attend) || 1;
    let r;
    if (tab === 'member' && picked) {
      r = addReservation({ sessionId: session.id, studentId: picked.id, name: picked.name, school: picked.school, grade: picked.grade, phone: picked.parentPhone, channel: 'manual', attendCount, member: true });
    } else {
      r = addReservation({ sessionId: session.id, studentId: null, name: guest.name, school: guest.school, grade: guest.grade, phone: guest.phone, channel: 'manual', attendCount, member: false });
    }
    onDone(r);
  };

  const canSubmit = tab === 'member' ? !!picked : guest.name && guest.phone;

  return (
    <Dialog open={open} onClose={onClose} title="수동예약 등록" width={500}
      footer={<React.Fragment><Button variant="ghost" onClick={onClose}>닫기</Button><Button disabled={!canSubmit} onClick={submit} icon={<I.check size={15} />}>예약 등록</Button></React.Fragment>}>
      <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 14 }}>{session.title} · {session.date} {session.time}</div>
      <Tabs variant="pill" items={[{ label: '재원생', value: 'member' }, { label: '비재원생', value: 'guest' }]} value={tab} onChange={setTab} />

      {tab === 'member' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 18 }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
            <Input label="학부모 연락처로 조회" placeholder="번호 일부 입력 (예: 3200)" value={phone} onChange={setPhone} icon={<I.search size={16} />} style={{ flex: 1 }} />
            <Button variant="secondary" onClick={search}>조회</Button>
          </div>
          {searched && searched.length === 0 && <div style={{ fontSize: 13, color: 'var(--status-danger)' }}>일치하는 재원생이 없어요. 번호를 확인하거나 비재원생 탭을 이용하세요.</div>}
          {searched && searched.slice(0, 4).map((s, i) => {
            const dup = already(s.id);
            const sel = picked && picked.id === s.id;
            return (
              <div key={s.id} onClick={() => !dup && setPicked(sel ? null : s)}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 'var(--radius-md)', cursor: dup ? 'not-allowed' : 'pointer', opacity: dup ? 0.55 : 1, background: sel ? 'var(--surface-brand-soft)' : 'var(--surface-sunken)', border: sel ? '1.5px solid var(--violet-800)' : '1px solid transparent', transform: sel ? 'scale(1.01)' : 'scale(1)', transition: 'all var(--dur-fast) var(--ease-spring)', animation: `ds-fade-up var(--dur-base) var(--ease-out) ${i * 60}ms both` }}>
                <span style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--violet-100)', color: 'var(--violet-900)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>{s.name[0]}</span>
                <span style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14.5, color: 'var(--text-strong)' }}>{s.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>{s.school} · {s.grade} · {s.className}</div>
                </span>
                {dup ? <Badge tone="neutral" size="sm">이미 예약됨</Badge> : sel ? <Badge tone="success" dot size="sm">선택됨</Badge> : <span style={{ fontSize: 12, color: 'var(--text-faint)' }}>선택</span>}
              </div>
            );
          })}
        </div>
      )}

      {tab === 'guest' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 18 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="학생 이름" placeholder="정하윤" value={guest.name} onChange={(v) => setGuest({ ...guest, name: v })} />
            <Input label="학교" placeholder="동성중" value={guest.school} onChange={(v) => setGuest({ ...guest, school: v })} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Input label="학년" placeholder="중3" value={guest.grade} onChange={(v) => setGuest({ ...guest, grade: v })} />
            <Input label="학부모 연락처" placeholder="010-0000-0000" value={guest.phone} onChange={(v) => setGuest({ ...guest, phone: v })} />
          </div>
        </div>
      )}

      {session.attendField && (
        <div style={{ marginTop: 14 }}>
          <Select label="참석 인원" options={['1명', '2명', '3명', '4명']} value={attend} onChange={setAttend} />
        </div>
      )}
      <div style={{ marginTop: 14, fontSize: 12.5, color: 'var(--text-faint)', display: 'flex', gap: 7, alignItems: 'center' }}>
        <I.qr size={13} /> 등록과 동시에 QR이 생성되고, 예약자 번호로 확정 문자가 발송돼요.
      </div>
    </Dialog>
  );
}
window.ManualReserveDialog = ManualReserveDialog;
