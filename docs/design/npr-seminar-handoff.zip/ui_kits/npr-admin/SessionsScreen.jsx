/* 설명회 운영 — QR 운영 대시보드 + 새 설명회 생성/삭제 + 수동 체크인 */
function SessionsScreen({ store }) {
  const { Button, Input, Card, Badge, Dialog, Toast, Switch, Tag, Select } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { sessions, reservations, addSession, deleteSession, checkIn, rollbackEntry, endSession, toggleReminder, addSmsLog, surveyResponses, convertGuest, classes, students, teachers, addReservation } = store;

  const [selId, setSelId] = React.useState(sessions[0]?.id);
  const [createOpen, setCreateOpen] = React.useState(false);
  const [delOpen, setDelOpen] = React.useState(false);
  const [endOpen, setEndOpen] = React.useState(false);
  const [listFilter, setListFilter] = React.useState('전체');
  const [rollbackTarget, setRollbackTarget] = React.useState(null);
  const [rollbackReason, setRollbackReason] = React.useState('QR 오스캔');
  const [convertTarget, setConvertTarget] = React.useState(null);
  const [convertClass, setConvertClass] = React.useState(null);
  const [printMode, setPrintMode] = React.useState(false);
  const [teacherFilter, setTeacherFilter] = React.useState('all');
  const [classFilter, setClassFilter] = React.useState('all');
  const [toast, setToast] = React.useState(null);
  const [form, setForm] = React.useState({ title: '', date: '', round: '1회차', place: '', capacity: '', desc: '', descOn: false, attendField: false, notice: '', banner: 'violet' });

  const session = sessions.find((s) => s.id === selId) || sessions[0];
  const rs = session ? reservations.filter((r) => r.sessionId === session.id) : [];
  const entered = rs.filter((r) => r.status === 'entered');
  const unchecked = rs.filter((r) => r.status === 'reserved');
  const cancelled = rs.filter((r) => r.status === 'cancelled');
  const noShow = rs.filter((r) => r.status === 'no_show');
  const activeRs = rs.filter((r) => r.status !== 'cancelled' && r.status !== 'no_show');
  const occupancy = session ? Math.round((activeRs.length / session.capacity) * 100) : 0;

  /* QR 현황 대시보드 — 해당 설명회 기준 재학생 전체 명단 + 비재원생 */
  const clsOf = (id) => classes.find((c) => c.id === id);
  const studentRows = (students || []).map((st) => {
    const r = reservations.find((x) => x.sessionId === (session && session.id) && x.studentId === st.id);
    return { key: 'stu-' + st.id, name: st.name, school: st.school, grade: st.grade, className: st.className, phone: st.parentPhone, code: r ? r.code : null, status: r ? r.status : 'none', member: true, r, st, teacherId: clsOf(st.classId) ? clsOf(st.classId).teacherId : null, classId: st.classId };
  });
  const guestRows = rs.filter((r) => !r.member).map((r) => ({ key: 'g-' + r.id, name: r.name, school: r.school, grade: r.grade, className: '비재원', phone: r.phone, code: r.code, status: r.status, member: false, r, st: null, teacherId: null, classId: null }));
  const matchCat = (row) => listFilter === '전체' ? row.status !== 'cancelled' : listFilter === '입장' ? row.status === 'entered' : listFilter === '미입장' ? row.status === 'reserved' : listFilter === '미예약' ? row.status === 'none' : listFilter === '노쇼' ? row.status === 'no_show' : listFilter === '취소' ? row.status === 'cancelled' : listFilter === '비재원생' ? row.member === false : true;
  const matchTC = (row) => {
    if (teacherFilter === 'all' && classFilter === 'all') return true;
    if (row.member === false) return false;
    if (teacherFilter !== 'all' && row.teacherId !== teacherFilter) return false;
    if (classFilter !== 'all' && row.classId !== classFilter) return false;
    return true;
  };
  const roster = [...studentRows, ...guestRows].filter((row) => matchCat(row) && matchTC(row));
  const unreservedCount = studentRows.filter((r) => r.status === 'none').length;
  const monTeacher = teachers.find((t) => t.id === teacherFilter);
  const monRows = teacherFilter === 'all' ? [] : studentRows.filter((r) => r.teacherId === teacherFilter);
  const monReserved = monRows.filter((r) => r.r && r.r.status !== 'cancelled' && r.r.status !== 'no_show');
  const monEntered = monRows.filter((r) => r.status === 'entered');
  const monUnres = monRows.filter((r) => r.status === 'none');

  const surveyRs = (surveyResponses || []).filter((r) => session && r.sessionId === session.id);
  const avgRating = surveyRs.length ? (surveyRs.reduce((a, b) => a + b.rating, 0) / surveyRs.length) : 0;
  const respRate = entered.length ? Math.round((surveyRs.length / entered.length) * 100) : 0;
  const ratingDist = [5, 4, 3, 2, 1].map((n) => ({ n, c: surveyRs.filter((r) => r.rating === n).length }));

  const flash = (m) => { setToast(m); setTimeout(() => setToast(null), 3000); };
  const submitCreate = () => {
    const s = addSession({ title: form.title, date: form.date, round: form.round, time: '10:00', place: form.place, capacity: parseInt(form.capacity) || 50, desc: form.desc, attendField: form.attendField, notice: form.notice, banner: form.banner });
    setCreateOpen(false);
    setForm({ title: '', date: '', round: '1회차', place: '', capacity: '', desc: '', descOn: false, attendField: false, notice: '', banner: 'violet' });
    setSelId(s.id);
    flash('설명회가 생성됐어요 — 모바일 예약 화면에 바로 노출됩니다');
  };
  const submitDelete = () => { deleteSession(session.id); setDelOpen(false); setSelId(sessions.find((s) => s.id !== session.id)?.id); flash('설명회가 삭제됐어요'); };
  const doCheckIn = (r) => { checkIn(r.id); flash(`${r.name} 님 입장 완료 — 입장 안내 문자를 발송했어요`); };
  const doInstantReserve = (st) => { addReservation({ sessionId: session.id, studentId: st.id, name: st.name, school: st.school, grade: st.grade, phone: st.parentPhone, channel: 'manual', attendCount: 1, member: true }); flash(`${st.name} 님을 즉석 예약 등록했어요`); };
  const doRollback = () => { rollbackEntry(rollbackTarget.id, rollbackReason); const n = rollbackTarget.name; setRollbackTarget(null); flash(`${n} 님의 입장을 취소했어요 — 미체크로 복귀했습니다`); };
  const doEnd = () => { const n = unchecked.length; endSession(session.id); setEndOpen(false); flash(`설명회를 종료했어요 — 미입장 ${n}명을 노쇼로 처리했습니다`); };
  const doSurvey = () => { addSmsLog({ to: entered.length, template: '만족도 설문 요청', session: session.title, ok: entered.length, fail: 0 }); flash(`입장 완료 ${entered.length}명에게 설문 링크를 발송했어요`); };
  const doReminderNow = (rm) => { addSmsLog({ to: unchecked.length, template: rm.template, session: session.title, ok: unchecked.length, fail: 0, auto: true }); flash(`${rm.label}를 미체크 ${unchecked.length}명에게 발송했어요`); };
  const doConvert = () => { convertGuest(convertTarget, convertClass); const n = convertTarget.name; setConvertTarget(null); flash(`${n} 님을 재원생으로 전환했어요 — 등록 환영 문자를 발송했어요`); };

  return (
    <div data-screen-label="설명회 운영 대시보드">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div>
          <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)', marginBottom: 6 }}>QR OPERATIONS</div>
          <h1 style={{ fontSize: 'var(--text-h1)', fontWeight: 800 }}>설명회 운영</h1>
        </div>
        <Button icon={<I.plus size={16} />} onClick={() => setCreateOpen(true)}>새 설명회</Button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: 14, marginTop: 20, alignItems: 'start' }}>
        {/* 설명회 목록 */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {sessions.map((s, i) => {
            const srs = reservations.filter((r) => r.sessionId === s.id && r.status !== 'cancelled');
            const sel = s.id === selId;
            return (
              <div key={s.id} onClick={() => setSelId(s.id)} style={{ padding: '16px 18px', borderRadius: 'var(--radius-lg)', cursor: 'pointer', background: sel ? 'var(--surface-brand-soft)' : 'var(--surface-card)', color: 'var(--text-body)', border: sel ? '1.5px solid var(--violet-800)' : '1px solid var(--border-hairline)', boxShadow: sel ? 'var(--shadow-accent-glow)' : 'var(--shadow-card)', transform: sel ? 'scale(1.02)' : 'scale(1)', transition: 'all var(--dur-base) var(--ease-spring)', animation: `ds-fade-up var(--dur-slow) var(--ease-out) ${i * 70}ms both` }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: sel ? 'var(--text-brand)' : 'var(--text-strong)', lineHeight: 1.4 }}>{s.title}</div>
                <div style={{ fontSize: 12, marginTop: 5, color: 'var(--text-muted)' }}>{s.date} · {s.round} · {s.time}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10 }}>
                  <span style={{ flex: 1, height: 5, borderRadius: 3, background: sel ? 'var(--violet-100)' : 'var(--gray-2)', overflow: 'hidden' }}>
                    <span style={{ display: 'block', height: '100%', width: `${Math.min(100, (srs.length / s.capacity) * 100)}%`, background: sel ? 'var(--violet-700)' : 'var(--violet-600)', transition: 'width var(--dur-hero) var(--ease-smooth)' }}></span>
                  </span>
                  <span style={{ fontSize: 11.5, fontWeight: 700, fontFeatureSettings: '"tnum"', color: sel ? 'var(--text-brand)' : 'var(--text-muted)', whiteSpace: 'nowrap', flexShrink: 0 }}>{srs.length}/{s.capacity}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* 선택 설명회 대시보드 */}
        {session && (
          <div key={session.id} style={{ display: 'flex', flexDirection: 'column', gap: 14, animation: 'ds-fade-up var(--dur-base) var(--ease-out) both' }}>
            <Card padding="20px 24px" style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <h2 style={{ fontSize: 20, fontWeight: 800 }}>{session.title}</h2>
                  {session.attendField && <Badge tone="accent" size="sm">참석 인원 수집</Badge>}
                  {session.ended && <Badge tone="neutral" size="sm">종료됨</Badge>}
                </div>
                <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 5, display: 'flex', gap: 14 }}>
                  <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}><I.calendar size={13} /> {session.date} {session.time}</span>
                  <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}><I.mapPin size={13} /> {session.place}</span>
                  <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}><I.users size={13} /> 정원 {session.capacity}명</span>
                </div>
                {session.desc && <div style={{ fontSize: 12.5, color: 'var(--text-faint)', marginTop: 6 }}>{session.desc}</div>}
              </div>
              <div style={{ textAlign: 'center', padding: '0 8px' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 30, color: occupancy >= 90 ? 'var(--status-danger)' : 'var(--violet-800)', fontFeatureSettings: '"tnum"', whiteSpace: 'nowrap' }}>{occupancy}%</div>
                <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>예약률</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 9 }}>
                <Button variant="secondary" size="sm" icon={<I.star size={14} />} onClick={doSurvey} disabled={entered.length === 0}>설문 보내기</Button>
                <div style={{ display: 'flex', gap: 14 }}>
                  {!session.ended && <a onClick={() => setEndOpen(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12.5, fontWeight: 600, color: 'var(--text-muted)', textDecoration: 'underline', textUnderlineOffset: 3, cursor: 'pointer', whiteSpace: 'nowrap' }}><I.check size={12} /> 설명회 종료</a>}
                  <a onClick={() => setDelOpen(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12.5, fontWeight: 600, color: 'var(--status-danger)', textDecoration: 'underline', textUnderlineOffset: 3, cursor: 'pointer', whiteSpace: 'nowrap' }}><I.trash size={12} /> 삭제</a>
                </div>
              </div>
            </Card>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
              <StatCard label="총 예약" value={activeRs.length} suffix={`/ ${session.capacity}`} tone="brand" icon={<I.ticket size={15} />} delay={0} />
              <StatCard label="입장 완료" value={entered.length} suffix="명" tone="success" icon={<I.check size={15} />} delay={50} />
              <StatCard label="미체크" value={unchecked.length} suffix="명" tone="accent" icon={<I.clock size={15} />} delay={100} />
              <StatCard label="노쇼" value={noShow.length} suffix="명" tone="neutral" icon={<I.alertTriangle size={15} />} delay={150} />
              <StatCard label="취소" value={cancelled.length} suffix="건" tone="danger" icon={<I.x size={15} />} delay={200} />
            </div>

            {monTeacher && (
              <Card variant="brand" padding="16px 22px" style={{ display: 'flex', alignItems: 'center', gap: 24, animation: 'ds-pop var(--dur-slow) var(--ease-spring) both' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ width: 40, height: 40, borderRadius: '50%', background: 'rgba(56,189,248,0.18)', color: 'var(--mint-400)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15 }}>{monTeacher.name[0]}</span>
                  <div>
                    <div style={{ fontWeight: 800, fontFamily: 'var(--font-display)', fontSize: 15.5 }}>{monTeacher.name} 강사 담당 · 이 설명회</div>
                    <div style={{ fontSize: 12, opacity: 0.75 }}>{classes.filter((c) => c.teacherId === teacherFilter).map((c) => c.name).join(' · ')}</div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 22, marginLeft: 'auto', fontFeatureSettings: '"tnum"' }}>
                  {[['담당 학생', monRows.length], ['예약', monReserved.length], ['입장 완료', monEntered.length], ['미예약', monUnres.length]].map(([k, v], i) => (
                    <div key={k} style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 11.5, opacity: 0.7 }}>{k}</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 21, color: i === 2 ? 'var(--mint-400)' : 'var(--gray-0)' }}>{v}</div>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* 리마인드 스케줄 + 만족도 요약 */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <Card padding="18px 20px">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <I.bell size={15} style={{ color: 'var(--violet-800)' }} />
                  <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>리마인드 스케줄</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-faint)', marginBottom: 12 }}>설정한 시각에 미체크 예약자에게 자동 발송돼요.</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {(session.reminders || []).map((rm) => (
                    <div key={rm.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 'var(--radius-md)', background: rm.enabled ? 'var(--surface-brand-soft)' : 'var(--surface-sunken)', border: '1px solid var(--border-hairline)' }}>
                      <Switch checked={rm.enabled} onChange={() => toggleReminder(session.id, rm.id)} />
                      <span style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-strong)' }}>{rm.label}</div>
                        <div style={{ fontSize: 11.5, color: 'var(--text-muted)', fontFeatureSettings: '"tnum"' }}>{rm.time} · {rm.template}</div>
                      </span>
                      <Button variant="ghost" size="sm" icon={<I.send size={12} />} onClick={() => doReminderNow(rm)} disabled={unchecked.length === 0}>지금</Button>
                    </div>
                  ))}
                </div>
              </Card>
              <Card padding="18px 20px">
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                  <I.star size={15} style={{ color: 'var(--mint-600)' }} />
                  <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>만족도 설문</span>
                  <span style={{ flex: 1 }}></span>
                  <span style={{ fontSize: 12, color: 'var(--text-faint)', fontFeatureSettings: '"tnum"' }}>응답률 {respRate}%</span>
                </div>
                {surveyRs.length === 0 ? (
                  <div style={{ padding: '18px 0', textAlign: 'center', color: 'var(--text-faint)', fontSize: 13 }}>아직 응답이 없어요.<br />종료 후 설문을 보내보세요.</div>
                ) : (
                  <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                    <div style={{ textAlign: 'center', flexShrink: 0 }}>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 34, color: 'var(--mint-600)', fontFeatureSettings: '"tnum"', lineHeight: 1 }}>{avgRating.toFixed(1)}</div>
                      <div style={{ display: 'flex', gap: 1, marginTop: 5, justifyContent: 'center' }}>{[1, 2, 3, 4, 5].map((n) => <I.star key={n} size={11} style={{ color: n <= Math.round(avgRating) ? 'var(--mint-500)' : 'var(--gray-3)', fill: n <= Math.round(avgRating) ? 'var(--mint-500)' : 'none' }} />)}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-faint)', marginTop: 4 }}>응답 {surveyRs.length}건</div>
                    </div>
                    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
                      {ratingDist.map((d) => (
                        <div key={d.n} style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                          <span style={{ fontSize: 10.5, color: 'var(--text-faint)', width: 20, fontFeatureSettings: '"tnum"' }}>{d.n}점</span>
                          <span style={{ flex: 1, height: 6, borderRadius: 3, background: 'var(--gray-2)', overflow: 'hidden' }}><span style={{ display: 'block', height: '100%', width: `${surveyRs.length ? (d.c / surveyRs.length) * 100 : 0}%`, background: 'var(--mint-500)', transition: 'width var(--dur-hero) var(--ease-smooth)' }}></span></span>
                          <span style={{ fontSize: 10.5, color: 'var(--text-muted)', width: 14, textAlign: 'right', fontFeatureSettings: '"tnum"' }}>{d.c}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </Card>
            </div>

            {/* 설명회 명단 (재학생 전체 + 비재원생) */}
            <Card padding="0" style={{ overflow: 'hidden' }}>
              <div style={{ padding: '13px 20px', borderBottom: '1px solid var(--border-hairline)', display: 'flex', flexDirection: 'column', gap: 11 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-strong)' }}>설명회 명단</span>
                  <span style={{ fontSize: 12.5, color: 'var(--text-faint)', fontFeatureSettings: '"tnum"' }}>{roster.length}명 · 미예약 {unreservedCount}</span>
                  <span style={{ flex: 1 }}></span>
                  <Select options={[{ label: '강사 전체', value: 'all' }].concat(teachers.map((t) => ({ label: t.name + ' 강사', value: t.id })))} value={teacherFilter} onChange={setTeacherFilter} style={{ width: 128 }} />
                  <Select options={[{ label: '반 전체', value: 'all' }].concat(classes.map((c) => ({ label: c.name, value: c.id })))} value={classFilter} onChange={setClassFilter} style={{ width: 118 }} />
                  <Button variant="ghost" size="sm" icon={<I.printer size={13} />} onClick={() => setPrintMode(true)}>명단 인쇄</Button>
                </div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {['전체', '입장', '미입장', '미예약', '노쇼', '비재원생', '취소'].map((f) => <Tag key={f} selected={listFilter === f} onClick={() => setListFilter(f)} style={{ height: 30 }}>{f}</Tag>)}
                </div>
              </div>
              {roster.map((row, i) => (
                <div key={row.key} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '13px 20px', borderTop: i > 0 ? '1px solid var(--border-hairline)' : 'none', animation: `ds-fade-up var(--dur-base) var(--ease-out) ${Math.min(i, 12) * 22}ms both` }}>
                  <span style={{ width: 160 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: 'var(--text-strong)', display: 'flex', gap: 6, alignItems: 'center' }}>{row.name} {!row.member && <Badge tone="accent" size="sm">비재원</Badge>} {row.r && row.r.groupId && <Badge tone="info" size="sm">형제</Badge>}</div>
                    <div style={{ fontSize: 11.5, color: 'var(--text-faint)' }}>{row.school} · {row.grade}</div>
                  </span>
                  <span style={{ fontSize: 12.5, color: 'var(--text-muted)', width: 84 }}>{row.className}</span>
                  <span style={{ fontSize: 12.5, color: 'var(--text-muted)', fontFeatureSettings: '"tnum"', width: 118 }}>{row.phone}</span>
                  <span style={{ fontSize: 12, color: 'var(--text-faint)', fontFeatureSettings: '"tnum"', width: 122 }}>{row.code || '—'}</span>
                  <span style={{ flex: 1 }}></span>
                  {row.status === 'none' ? <Badge tone="neutral" size="sm">미예약</Badge> : <ResStatusBadge status={row.status} size="sm" />}
                  {row.status === 'none' && <Button variant="secondary" size="sm" icon={<I.plus size={13} />} onClick={() => doInstantReserve(row.st)}>즉석 예약</Button>}
                  {row.status === 'reserved' && <Button variant="secondary" size="sm" icon={<I.logIn size={13} />} onClick={() => doCheckIn(row.r)}>수동 체크인</Button>}
                  {row.status === 'entered' && <Button variant="ghost" size="sm" icon={<I.rotateCcw size={13} />} onClick={() => { setRollbackReason('QR 오스캔'); setRollbackTarget(row.r); }} style={{ color: 'var(--text-muted)' }}>입장 취소</Button>}
                  {!row.member && row.status !== 'cancelled' && <Button variant="ghost" size="sm" icon={<I.userCheck size={13} />} onClick={() => { setConvertClass(classes[0].id); setConvertTarget(row.r); }} style={{ color: 'var(--text-accent)' }}>전환</Button>}
                </div>
              ))}
              {roster.length === 0 && <EmptyState>해당 조건의 명단이 없어요.</EmptyState>}
            </Card>
          </div>
        )}
      </div>

      {/* 새 설명회 생성 */}
      <Dialog open={createOpen} onClose={() => setCreateOpen(false)} title="새 설명회 만들기" width={520}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setCreateOpen(false)}>취소</Button><Button disabled={!form.title || !form.date || !form.place} onClick={submitCreate} icon={<I.check size={15} />}>생성하기</Button></React.Fragment>}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Input label="설명회명" placeholder="2027 대비 고등 입시전략 설명회" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
          <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr 1fr', gap: 12 }}>
            <Input label="날짜" placeholder="8월 15일 (토)" value={form.date} onChange={(v) => setForm({ ...form, date: v })} />
            <Input label="회차" placeholder="1회차" value={form.round} onChange={(v) => setForm({ ...form, round: v })} />
            <Input label="정원" placeholder="100" value={form.capacity} onChange={(v) => setForm({ ...form, capacity: v })} />
          </div>
          <Input label="장소" placeholder="npr 본관 5층 세미나홀" value={form.place} onChange={(v) => setForm({ ...form, place: v })} />
          <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            <span style={{ fontSize: 13, fontWeight: 'var(--weight-semibold)', color: 'var(--text-strong)' }}>설명 <span style={{ color: 'var(--text-faint)', fontWeight: 500 }}>(선택)</span></span>
            <textarea value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} rows={3} placeholder="설명회 소개를 입력하세요"
              style={{ width: '100%', padding: '12px 16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-soft)', background: 'var(--surface-card)', fontFamily: 'var(--font-body)', fontSize: 14, lineHeight: 1.6, color: 'var(--text-strong)', resize: 'vertical', outline: 'none', boxSizing: 'border-box' }} />
          </label>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, padding: '14px 16px', borderRadius: 'var(--radius-md)', background: 'var(--surface-sunken)' }}>
            <Switch label="참석 인원 필드" checked={form.attendField} onChange={(v) => setForm({ ...form, attendField: v })} />
            <span style={{ fontSize: 12, color: 'var(--text-faint)', paddingLeft: 56 }}>예약 화면에서 참석 인원을 선택받습니다.</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: '16px', borderRadius: 'var(--radius-md)', border: '1px dashed var(--border-soft)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
              <I.image size={15} style={{ color: 'var(--violet-800)' }} />
              <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text-strong)' }}>페이지 꾸미기 <span style={{ color: 'var(--text-faint)', fontWeight: 500 }}>(모바일 예약 화면)</span></span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)' }}>배너 테마</span>
              <div style={{ display: 'flex', gap: 8 }}>
                {[['violet', '네이비', 'var(--violet-900)'], ['mint', '스카이', 'var(--mint-500)'], ['slate', '슬레이트', 'var(--violet-950)']].map(([k, lbl, col]) => (
                  <button key={k} onClick={() => setForm({ ...form, banner: k })} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '7px 12px', borderRadius: 'var(--radius-pill)', border: form.banner === k ? '1.5px solid var(--violet-800)' : '1px solid var(--border-soft)', background: form.banner === k ? 'var(--surface-brand-soft)' : 'var(--surface-card)', cursor: 'pointer', fontFamily: 'var(--font-body)', fontSize: 12.5, fontWeight: 600, color: 'var(--text-body)' }}>
                    <span style={{ width: 14, height: 14, borderRadius: '50%', background: col }}></span>{lbl}
                  </button>
                ))}
              </div>
            </div>
            <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)' }}>안내문</span>
              <textarea value={form.notice} onChange={(e) => setForm({ ...form, notice: e.target.value })} rows={2} placeholder="예: 주차는 본관 지하를 이용해 주세요. 자료집은 현장에서 배부합니다."
                style={{ width: '100%', padding: '11px 14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-soft)', background: 'var(--surface-card)', fontFamily: 'var(--font-body)', fontSize: 13.5, lineHeight: 1.55, color: 'var(--text-strong)', resize: 'vertical', outline: 'none', boxSizing: 'border-box' }} />
            </label>
          </div>
        </div>
      </Dialog>

      {/* 삭제 확인 */}
      <Dialog open={delOpen} onClose={() => setDelOpen(false)} title="설명회를 삭제할까요?"
        footer={<React.Fragment><Button variant="ghost" onClick={() => setDelOpen(false)}>돌아가기</Button><Button variant="danger" onClick={submitDelete} icon={<I.trash size={14} />}>삭제</Button></React.Fragment>}>
        {session && <span><b>{session.title}</b>과 예약 {activeRs.length}건이 함께 삭제됩니다. 예약자에게 취소 안내 문자가 발송돼요.</span>}
      </Dialog>

      {/* 설명회 종료 — 미체크 자동 노쇼 */}
      <Dialog open={endOpen} onClose={() => setEndOpen(false)} title="설명회를 종료할까요?" width={440}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setEndOpen(false)}>돌아가기</Button><Button onClick={doEnd} icon={<I.check size={15} />}>종료 처리</Button></React.Fragment>}>
        {session && <span style={{ lineHeight: 1.55 }}><b>{session.title}</b>을 종료합니다. 아직 <b>미체크인 {unchecked.length}명</b>은 <b>노쇼</b>로 자동 처리되고, 재원생 노쇼 회수에 누적돼요.</span>}
      </Dialog>

      {/* 입장 취소(롤백) */}
      <Dialog open={!!rollbackTarget} onClose={() => setRollbackTarget(null)} title="입장을 취소할까요?" width={440}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setRollbackTarget(null)}>돌아가기</Button><Button variant="danger" onClick={doRollback} icon={<I.rotateCcw size={14} />}>입장 취소</Button></React.Fragment>}>
        {rollbackTarget && <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span style={{ fontSize: 13.5, color: 'var(--text-muted)', lineHeight: 1.55 }}><b style={{ color: 'var(--text-strong)' }}>{rollbackTarget.name}</b> 님을 <b>입장 완료 → 미체크</b>로 되돌립니다. 처리 이력은 감사 로그에 기록돼요.</span>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-strong)' }}>취소 사유</span>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {['QR 오스캔', '중복 쳋크인', '본인 미참석', '기타'].map((rz) => <Tag key={rz} selected={rollbackReason === rz} onClick={() => setRollbackReason(rz)} style={{ height: 32 }}>{rz}</Tag>)}
            </div>
          </div>
        </div>}
      </Dialog>

      {/* 비재원생 → 재원생 전환 (학생 추가 프리필) */}
      <Dialog open={!!convertTarget} onClose={() => setConvertTarget(null)} title="재원생으로 전환" width={460}
        footer={<React.Fragment><Button variant="ghost" onClick={() => setConvertTarget(null)}>취소</Button><Button onClick={doConvert} icon={<I.userCheck size={15} />}>전환하기</Button></React.Fragment>}>
        {convertTarget && <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.55 }}>설명회 참석자 <b style={{ color: 'var(--text-strong)' }}>{convertTarget.name}</b> 님을 재원생 명단에 등록해요. 반을 배정하면 이 예약이 재원생 예약으로 연결돼요.</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, padding: '14px 16px', borderRadius: 'var(--radius-md)', background: 'var(--surface-sunken)' }}>
            <KV k="이름" v={convertTarget.name} />
            <KV k="연락처" v={convertTarget.phone} />
            <KV k="학교" v={convertTarget.school || '—'} />
            <KV k="학년" v={convertTarget.grade || '—'} />
          </div>
          <Select label="배정할 반" options={classes.map((c) => ({ label: c.name, value: c.id }))} value={convertClass} onChange={setConvertClass} />
        </div>}
      </Dialog>

      {/* 참석자 명단 인쇄 — A4 뷰 (체크박스·서명란) */}
      {printMode && session && (
        <div className="npr-print-wrap" style={{ position: 'fixed', inset: 0, background: 'var(--gray-2)', zIndex: 200, overflow: 'auto', padding: '30px 20px' }}>
          <style>{`@media print { body * { visibility: hidden !important; } #npr-print-roster, #npr-print-roster * { visibility: visible !important; } #npr-print-roster { position: absolute !important; left: 0; top: 0; width: 100% !important; box-shadow: none !important; border-radius: 0 !important; } .npr-print-toolbar { display: none !important; } .npr-print-wrap { background: #fff !important; padding: 0 !important; } @page { size: A4; margin: 14mm; } }`}</style>
          <div className="npr-print-toolbar" style={{ maxWidth: 794, margin: '0 auto 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>인쇄 미리보기 · A4 · 총 {rs.filter((r) => r.status !== 'cancelled').length}명</span>
            <div style={{ display: 'flex', gap: 8 }}>
              <Button variant="ghost" onClick={() => setPrintMode(false)}>닫기</Button>
              <Button icon={<I.printer size={15} />} onClick={() => window.print()}>인쇄하기</Button>
            </div>
          </div>
          <div id="npr-print-roster" style={{ maxWidth: 794, margin: '0 auto', background: '#fff', boxShadow: 'var(--shadow-float)', padding: '38px 40px', color: '#111827', fontFamily: 'var(--font-body)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '2px solid #111827', paddingBottom: 14 }}>
              <div>
                <div style={{ fontSize: 12, letterSpacing: '0.12em', fontWeight: 700, color: '#6B7280' }}>NPR 입시설명회 · 참석자 명단</div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22, marginTop: 6 }}>{session.title}</div>
                <div style={{ fontSize: 13, color: '#4B5563', marginTop: 6 }}>{session.date} {session.time} · {session.round} · {session.place} · 정원 {session.capacity}명</div>
              </div>
              <div style={{ textAlign: 'right', fontSize: 12, color: '#6B7280' }}>
                <div>총 {rs.filter((r) => r.status !== 'cancelled').length}명</div>
                <div style={{ marginTop: 4 }}>인쇄일 2026-07-15</div>
              </div>
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 16, fontSize: 12.5 }}>
              <thead>
                <tr style={{ background: '#F3F4F6' }}>
                  {['No', '이름', '학교', '학년', '연락처', '예약번호', '체크', '서명'].map((h, i) => (
                    <th key={h} style={{ textAlign: i > 5 ? 'center' : 'left', padding: '9px 10px', borderBottom: '1px solid #D1D5DB', fontWeight: 700, color: '#374151', width: i === 6 ? 44 : i === 7 ? 110 : 'auto' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rs.filter((r) => r.status !== 'cancelled').map((r, i) => (
                  <tr key={r.id}>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB', color: '#6B7280', fontVariantNumeric: 'tabular-nums' }}>{i + 1}</td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB', fontWeight: 700 }}>{r.name}{!r.member && <span style={{ fontSize: 10.5, color: '#9CA3AF', marginLeft: 5 }}>비재원</span>}</td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB' }}>{r.school}</td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB' }}>{r.grade}</td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB', fontVariantNumeric: 'tabular-nums' }}>{r.phone}</td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB', fontVariantNumeric: 'tabular-nums', color: '#6B7280' }}>{r.code}</td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB', textAlign: 'center' }}><span style={{ display: 'inline-block', width: 16, height: 16, border: '1.5px solid #9CA3AF', borderRadius: 3 }}></span></td>
                    <td style={{ padding: '9px 10px', borderBottom: '1px solid #E5E7EB' }}></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{ marginTop: 20, fontSize: 11.5, color: '#9CA3AF', display: 'flex', justifyContent: 'space-between' }}>
              <span>· 입장 시 체크란에 표시하고 서명을 받아 주세요.</span>
              <span>npr 입시설명회 운영팀</span>
            </div>
          </div>
        </div>
      )}

      {toast && <div style={{ position: 'fixed', bottom: 26, left: '50%', transform: 'translateX(-50%)', zIndex: 120 }}><Toast tone="success">{toast}</Toast></div>}
    </div>
  );
}
window.SessionsScreen = SessionsScreen;
