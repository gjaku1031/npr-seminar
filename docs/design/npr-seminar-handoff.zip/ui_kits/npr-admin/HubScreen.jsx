/* 카드 런처 허브 — 메인 화면 */
function HubScreen({ store, go, allowed }) {
  const { LauncherCard } = window.DesignSystem_179b2a;
  const I = window.NPRIcons;
  const { students, sessions, reservations, smsLogs, devices, counselBookings } = store;
  const can = (m) => !allowed || allowed.includes(m);

  const s0 = sessions[0];
  const activeRs = (sid) => reservations.filter((r) => r.sessionId === sid && r.status !== 'cancelled');
  const reservedStu = new Set(reservations.filter((r) => r.status !== 'cancelled' && r.studentId).map((r) => r.studentId));
  const unreserved = students.filter((st) => !reservedStu.has(st.id)).length;
  const phoneCnt = reservations.filter((r) => r.channel === 'phone' && r.status !== 'cancelled').length;
  const unchecked = s0 ? activeRs(s0.id).filter((r) => r.status === 'reserved').length : 0;
  const devOn = devices.filter((d) => d.on).length;

  return (
    <div data-screen-label="허브 — 카드 런처" style={{ maxWidth: 980, margin: '0 auto', padding: '48px var(--container-pad) 80px' }}>
      <div style={{ animation: 'ds-fade-up var(--dur-slow) var(--ease-out) both' }}>
        <div style={{ fontSize: 12, letterSpacing: 'var(--tracking-caps)', fontWeight: 700, color: 'var(--text-accent)' }}>NPR ADMIN</div>
        <h1 style={{ fontSize: 'var(--text-display)', fontWeight: 800, letterSpacing: 'var(--tracking-display)', marginTop: 10 }}>무엇을 하시겠어요?</h1>
        {s0 && (
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, marginTop: 14, padding: '8px 16px', borderRadius: 'var(--radius-pill)', background: 'var(--surface-accent-soft)', color: 'var(--text-accent)', fontSize: 13.5, fontWeight: 700, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 100ms both' }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--mint-500)', animation: 'ds-float 2.2s var(--ease-in-out) infinite' }}></span>
            다가오는 설명회 — {s0.title} · {s0.date} {s0.time} · 미체크 {unchecked}명
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginTop: 30 }}>
        <LauncherCard icon={<I.users size={19} />} title="재원생 관리" stat={can('students') ? `${students.length}명 · 미예약 ${unreserved}` : '접근 권한 없음'} onClick={() => go('students')} locked={!can('students')} delay={0} />
        <LauncherCard icon={<I.phone size={18} />} title="전화예약" stat={can('phone') ? `전화 접수 ${phoneCnt}건` : '접근 권한 없음'} onClick={() => go('phone')} locked={!can('phone')} delay={70} />
        <LauncherCard icon={<I.message size={18} />} title="문자 발송" stat={can('sms') ? (smsLogs[0] ? `최근 발송 ${smsLogs[0].when}` : '발송 이력 없음') : '접근 권한 없음'} onClick={() => go('sms')} locked={!can('sms')} delay={140} />
        <LauncherCard icon={<I.qr size={18} />} title="설명회 운영" stat={can('sessions') ? `설명회 ${sessions.length}개 진행 중` : '접근 권한 없음'} onClick={() => go('sessions')} locked={!can('sessions')} delay={210} />
        <LauncherCard icon={<I.clipboard size={18} />} title="상담 예약" stat={can('counsel') ? `신청 ${(counselBookings || []).length}건` : '접근 권한 없음'} onClick={() => go('counsel')} locked={!can('counsel')} delay={280} />
        <LauncherCard icon={<I.tablet size={18} />} title="QR 스캐너" stat={can('scanner') ? `기기 ${devOn}대 ON` : '접근 권한 없음'} onClick={() => go('scanner')} locked={!can('scanner')} delay={350} />
        <LauncherCard icon={<I.smartphone size={18} />} title="모바일 프리뷰" stat={can('preview') ? '테스트 전용 시연' : '접근 권한 없음'} onClick={() => go('preview')} locked={!can('preview')} delay={420} />
        <LauncherCard icon={<I.barChart size={18} />} title="통계" stat={can('stats') ? '예약 · 참석 · 전환 지표' : '접근 권한 없음'} onClick={() => go('stats')} locked={!can('stats')} delay={490} />
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 26, animation: 'ds-fade-up var(--dur-slow) var(--ease-out) 450ms both' }}>
        <a href="mobile.html" target="_blank" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 13.5, fontWeight: 700, color: 'var(--text-muted)' }}>
          <I.smartphone size={15} /> 학부모용 모바일 예약 페이지 열기 →
        </a>
      </div>
    </div>
  );
}
window.HubScreen = HubScreen;
