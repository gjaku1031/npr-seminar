/* npr 유저플로우 데이터 — 권한별 페르소나 흐름 (구조화 · E2E/디버깅용)
   노드: { id, type, title, note?, state?, sms?, gate?, branches?:[{cond, nodes:[]}] }
   type: start | screen | action | decision | state | sms | gate | end
   ID 규칙: <PERSONA>-<FLOW>-<STEP> (예: OWNER-F5-04) */
(function () {
  const OWNER_FLOWS = [
    {
      id: 'OWNER-F1', name: '로그인 & 라우팅', desc: '역할 판별 → 허브 → 모듈 이동',
      nodes: [
        { id: 'OWNER-F1-01', type: 'start', title: '콘솔 접속 (index.html)' },
        { id: 'OWNER-F1-02', type: 'screen', title: '로그인 화면', note: '역할 선택: 원장 / 실장 / 강사. 학부모·학생은 로그인 없이 모바일(mobile.html)만 이용.' },
        { id: 'OWNER-F1-03', type: 'action', title: '원장 선택 → 입장하기' },
        { id: 'OWNER-F1-04', type: 'state', title: '로그인 상태 저장', state: 'npr-user = owner', note: '새로고침 유지. 미인식 역할이면 재로그인.' },
        { id: 'OWNER-F1-05', type: 'screen', title: '허브 (카드 런처)', note: '8개 모듈 카드 전부 활성 + 다가오는 설명회 칩 + 모바일 예약 링크.' },
        { id: 'OWNER-F1-06', type: 'decision', title: '모듈 진입', note: '카드/상단 탭바로 이동. 로고 클릭 시 허브 복귀. npr-route에 라우트 저장.', branches: [
          { cond: '재원생 관리', nodes: [{ id: 'OWNER-F1-06a', type: 'screen', title: '→ F2' }] },
          { cond: '설명회 운영', nodes: [{ id: 'OWNER-F1-06b', type: 'screen', title: '→ F5 (QR 현황 대시보드)' }] },
          { cond: '통계', nodes: [{ id: 'OWNER-F1-06c', type: 'screen', title: '→ F7' }] },
        ] },
        { id: 'OWNER-F1-07', type: 'action', title: '아바타 메뉴 → 로그아웃', note: '내 정보 / 로그아웃.' },
        { id: 'OWNER-F1-08', type: 'end', title: '로그인 화면 복귀 (npr-user 삭제)' },
      ],
    },
    {
      id: 'OWNER-F2', name: '재원생 관리 (전체 명단)', desc: '원장·실장 전용',
      nodes: [
        { id: 'OWNER-F2-01', type: 'screen', title: '재원생 명단 진입', note: '40명 시드. 필드: 이름(+전환 배지)·학교·학년·반·연락처·예약·입장·노쇼 회수.' },
        { id: 'OWNER-F2-02', type: 'action', title: '필터', note: '검색(이름·학교·연락처) · 부문(초/중/고) · 예약상태(전체/예약/입장/미예약) · 설명회 기준 Select. ※ 강사·반 필터는 F5로 이동.' },
        { id: 'OWNER-F2-03', type: 'decision', title: '우상단 액션', branches: [
          { cond: '학생 추가', nodes: [
            { id: 'OWNER-F2-04', type: 'screen', title: '학생 추가 모달' },
            { id: 'OWNER-F2-05', type: 'decision', title: '이름·연락처 입력?', note: '필수 미입력 시 추가 비활성.', branches: [
              { cond: '유효', nodes: [{ id: 'OWNER-F2-06', type: 'state', title: '명단 최상단 추가', state: '+Student', sms: '' }] },
            ] },
          ] },
          { cond: '엑셀 업로드', nodes: [
            { id: 'OWNER-F2-07', type: 'screen', title: '매핑 미리보기 모달', note: '열 매핑(이름·학교·학년·반·연락처) + 중복 행 하이라이트.' },
            { id: 'OWNER-F2-08', type: 'decision', title: '연락처 중복?', branches: [
              { cond: '중복', nodes: [{ id: 'OWNER-F2-09', type: 'state', title: '기존 재원생 병합' }] },
              { cond: '신규', nodes: [{ id: 'OWNER-F2-10', type: 'state', title: '명단 추가', state: '+Student' }] },
            ] },
          ] },
          { cond: '엑셀 다운로드', nodes: [{ id: 'OWNER-F2-11', type: 'action', title: '현재 필터 명단 .xlsx 내려받기' }] },
        ] },
      ],
    },
    {
      id: 'OWNER-F3', name: '전화예약 관리', desc: '수동예약 · QR/문자 상세',
      nodes: [
        { id: 'OWNER-F3-01', type: 'screen', title: '전화예약 진입 + 설명회 선택' },
        { id: 'OWNER-F3-02', type: 'action', title: '스탯 카드 클릭 = 목록 필터', note: '전화예약/입장/미체크/취소.' },
        { id: 'OWNER-F3-03', type: 'decision', title: '수동예약 등록', branches: [
          { cond: '재원생 탭', nodes: [
            { id: 'OWNER-F3-04', type: 'action', title: '연락처(부분) 조회 → 학생 카드 선택', note: '이미 예약된 학생은 비활성.' },
            { id: 'OWNER-F3-05', type: 'decision', title: 'attendField?', branches: [{ cond: 'true', nodes: [{ id: 'OWNER-F3-06', type: 'action', title: '참석 인원(1~4) 선택' }] }] },
            { id: 'OWNER-F3-07', type: 'state', title: '예약 생성 + QR', state: '→ reserved', sms: '예약 확정 + QR' },
          ] },
          { cond: '비재원생 탭', nodes: [
            { id: 'OWNER-F3-08', type: 'action', title: '이름·학교·학년·연락처 입력' },
            { id: 'OWNER-F3-09', type: 'state', title: '예약 생성(member=false)', state: '→ reserved', sms: '예약 확정 + QR' },
          ] },
        ] },
        { id: 'OWNER-F3-10', type: 'screen', title: '예약 상세 패널 (행 클릭)', note: 'QR·예약자·연락처·채널·일시·상태 + 이력(회차 변경/재발급).' },
        { id: 'OWNER-F3-11', type: 'decision', title: '상세 액션', branches: [
          { cond: '문자 재발송', nodes: [{ id: 'OWNER-F3-12', type: 'sms', title: '확정 문자 재발송', sms: '예약 확정 + QR' }] },
          { cond: 'QR 재발급', nodes: [{ id: 'OWNER-F3-13', type: 'state', title: '기존 코드 무효·신규 발급', state: 'code → -Rn (codeHistory)', sms: '재발급 QR' }] },
          { cond: '예약 변경', nodes: [
            { id: 'OWNER-F3-14', type: 'screen', title: '회차 선택 다이얼로그(잔여석)' },
            { id: 'OWNER-F3-15', type: 'state', title: '설명회 이동 (예약번호·QR 유지)', state: 'sessionId 이동 · history[]', sms: '변경 확정' },
          ] },
          { cond: '예약 취소', nodes: [
            { id: 'OWNER-F3-16', type: 'decision', title: '취소 확인 다이얼로그' },
            { id: 'OWNER-F3-17', type: 'state', title: '예약 취소', state: '→ cancelled (by staff)', sms: '취소 안내' },
          ] },
        ] },
      ],
    },
    {
      id: 'OWNER-F4', name: '문자 발송', desc: '템플릿 · 대상 · 로그',
      nodes: [
        { id: 'OWNER-F4-01', type: 'screen', title: '문자 발송 진입' },
        { id: 'OWNER-F4-02', type: 'action', title: '템플릿 선택 / 생성 / 저장' },
        { id: 'OWNER-F4-03', type: 'action', title: '본문 편집 + 변수 칩', note: '{학생명}{설명회명}{일시}{장소}{QR링크}. 바이트 카운터(>90 LMS).' },
        { id: 'OWNER-F4-04', type: 'action', title: '수신 대상 선택', note: '설명회 × 대상 그룹(예약자 전체/미체크/입장/취소자) + 인원 카운트.' },
        { id: 'OWNER-F4-05', type: 'decision', title: '발송 가능?', note: '대상 0명·빈 본문이면 비활성.', branches: [
          { cond: '가능', nodes: [{ id: 'OWNER-F4-06', type: 'state', title: '발송 → 로그 추가', sms: '선택 템플릿 · 대상 그룹' }] },
        ] },
        { id: 'OWNER-F4-07', type: 'screen', title: '발송 로그 대시보드', note: '시각/템플릿/설명회/수신/성공/실패 + 자동 배지(리마인드).' },
      ],
    },
    {
      id: 'OWNER-F5', name: '설명회 운영 — QR 현황 대시보드', desc: '전체 명단 관리 · 핵심',
      nodes: [
        { id: 'OWNER-F5-01', type: 'screen', title: '설명회 운영 진입 + 좌측 설명회 선택' },
        { id: 'OWNER-F5-02', type: 'action', title: '새 설명회 생성', note: '명*·날짜*·장소* + 참석 인원 토글 + 페이지 꾸미기(배너 테마·안내문).' },
        { id: 'OWNER-F5-03', type: 'state', title: '생성 + 자동 선택', state: '+Session', note: '모바일 예약 화면에 즉시 노출.' },
        { id: 'OWNER-F5-04', type: 'screen', title: '현황 헤더 + 스탯 5장', note: '총예약/입장/미체크/노쇼/취소 + 예약률%. (강사도 열람 가능)' },
        { id: 'OWNER-F5-05', type: 'action', title: '리마인드 스케줄 토글 / 지금 발송', sms: '전일·당일 리마인드 (자동 배지)' },
        { id: 'OWNER-F5-06', type: 'action', title: '설문 보내기 (입장>0)', sms: '만족도 설문 링크' },
        { id: 'OWNER-F5-07', type: 'screen', title: '설명회 명단 (전체 로스터)', note: '재원생 전체 + 비재원생. 강사·반 필터 + 상태 필터(전체/입장/미입장/미예약/노쇼/비재원생/취소). 강사 선택 시 강사 모니터링 카드.' },
        { id: 'OWNER-F5-08', type: 'decision', title: '명단 행 액션 (상태별)', branches: [
          { cond: '미예약 (재학생)', nodes: [{ id: 'OWNER-F5-09', type: 'state', title: '즉석 예약 등록', state: 'none → reserved', sms: '예약 확정 + QR' }] },
          { cond: '미입장 (reserved)', nodes: [{ id: 'OWNER-F5-10', type: 'state', title: '수동 체크인', state: 'reserved → entered', sms: '입장 완료 안내' }] },
          { cond: '입장 (entered)', nodes: [
            { id: 'OWNER-F5-11', type: 'decision', title: '입장 취소 → 사유 선택' },
            { id: 'OWNER-F5-12', type: 'state', title: '미체크 복귀 (감사 기록)', state: 'entered → reserved · audit[]' },
          ] },
          { cond: '비재원생', nodes: [
            { id: 'OWNER-F5-13', type: 'screen', title: '전환 → 반 배정(프리필)' },
            { id: 'OWNER-F5-14', type: 'state', title: '재원생 전환', state: '+Student · convertedFrom · 예약 연결', sms: '등록 환영' },
          ] },
        ] },
        { id: 'OWNER-F5-15', type: 'action', title: '명단 인쇄 → A4 로스터(체크·서명란) → 인쇄' },
        { id: 'OWNER-F5-16', type: 'decision', title: '설명회 종료', branches: [
          { cond: '종료 처리', nodes: [{ id: 'OWNER-F5-17', type: 'state', title: '미체크 일괄 노쇼 + 노쇼 회수 누적', state: 'reserved → no_show · Student.noShowCount++', sms: '(선택) 종료 안내' }] },
        ] },
        { id: 'OWNER-F5-18', type: 'decision', title: '설명회 삭제', branches: [
          { cond: '삭제 확인', nodes: [{ id: 'OWNER-F5-19', type: 'state', title: '세션 + 연동 예약 제거', state: '-Session · -Reservation', sms: '취소 안내' }] },
        ] },
      ],
    },
    {
      id: 'OWNER-F6', name: '상담 예약', desc: '슬롯 그리드 · 신청 모니터링',
      nodes: [
        { id: 'OWNER-F6-01', type: 'screen', title: '상담 예약 진입', note: '슬롯 그리드(강사×일시) + 신청 목록 + 전체/예약/잔여 스탯.' },
        { id: 'OWNER-F6-02', type: 'action', title: '강사 필터로 슬롯·신청 슬라이스' },
        { id: 'OWNER-F6-03', type: 'end', title: '신청 모니터링', note: '신청 생성은 학부모 모바일(→ PARENT-P5). 콘솔은 조회·관리.' },
      ],
    },
    {
      id: 'OWNER-F7', name: '통계 대시보드', desc: '원장·실장 전용',
      nodes: [
        { id: 'OWNER-F7-01', type: 'screen', title: '통계 진입' },
        { id: 'OWNER-F7-02', type: 'action', title: '지표 카드', note: '누적 예약 · 참석률 · 노쇼율 · 비재원 전환율.' },
        { id: 'OWNER-F7-03', type: 'action', title: '차트', note: '회차별 참석률 바 · 채널별 도넛 · 시간대 추이 라인 · 평균 만족도.' },
      ],
    },
    {
      id: 'OWNER-F8', name: 'QR 스캐너 (태블릿)', desc: '현장 입장 처리',
      nodes: [
        { id: 'OWNER-F8-01', type: 'screen', title: '기기 모니터링 (최대 4대)', note: '설치 위치·기종·ON/OFF·배터리(40%↓ 경고).' },
        { id: 'OWNER-F8-02', type: 'decision', title: '기기 선택', branches: [
          { cond: 'ON — 이 기기로 스캔', nodes: [{ id: 'OWNER-F8-03', type: 'screen', title: '전체화면 스캐너' }] },
          { cond: 'OFF — 연결하기', nodes: [{ id: 'OWNER-F8-04', type: 'screen', title: '카메라 권한(허용/거부)', note: '거부 시 기기 선택 복귀.' }] },
        ] },
        { id: 'OWNER-F8-05', type: 'decision', title: 'QR 인식 (데모)', branches: [
          { cond: '인식 성공', nodes: [{ id: 'OWNER-F8-06', type: 'state', title: '미체크 1건 입장 처리', state: 'reserved → entered', sms: '입장 완료 안내' }] },
        ] },
        { id: 'OWNER-F8-07', type: 'decision', title: '현장 입장 (연락처 뒤 4자리)', branches: [
          { cond: '재원생·기존 예약', nodes: [{ id: 'OWNER-F8-08', type: 'state', title: '체크인', state: 'reserved → entered', sms: '입장 완료' }] },
          { cond: '재원생·무예약', nodes: [{ id: 'OWNER-F8-09', type: 'state', title: '즉석 예약 + 체크인', state: '→ entered', sms: '입장 완료' }] },
          { cond: '비재원생', nodes: [{ id: 'OWNER-F8-10', type: 'action', title: '수동예약 등록 안내' }] },
        ] },
      ],
    },
    {
      id: 'OWNER-F9', name: '모바일 프리뷰', desc: '테스트 전용',
      nodes: [
        { id: 'OWNER-F9-01', type: 'screen', title: '폰 프레임 안 MobileFlow 구동', note: "'테스트 전용 · 실제 문자 미발송' 배지." },
        { id: 'OWNER-F9-02', type: 'state', title: '프리뷰 예약이 store 즉시 반영' },
        { id: 'OWNER-F9-03', type: 'action', title: '초기화 (플로우 처음으로)' },
      ],
    },
  ];

  const GANGSA_FLOWS = [
    {
      id: 'GANGSA-F1', name: '로그인 & 권한 게이팅', desc: '강사(=직원)',
      nodes: [
        { id: 'GANGSA-F1-01', type: 'screen', title: '로그인 화면 → 강사 선택', note: '강사 이름 선택 후 입장.' },
        { id: 'GANGSA-F1-02', type: 'state', title: '로그인 상태 저장', state: 'npr-user = gangsa' },
        { id: 'GANGSA-F1-03', type: 'screen', title: '허브', note: '재원생 관리 · 통계 카드는 잠금(자물쇠) 표시.', gate: '재원생 관리 · 통계 비활성' },
        { id: 'GANGSA-F1-04', type: 'decision', title: '접근 가능 모듈', branches: [
          { cond: '허용', nodes: [{ id: 'GANGSA-F1-05', type: 'screen', title: '전화예약·문자·설명회 운영·상담·QR 스캐너·프리뷰', note: '원장 F3·F4·F5·F6·F8·F9와 동일하게 보기+동작 가능.' }] },
          { cond: '차단', nodes: [{ id: 'GANGSA-F1-06', type: 'gate', title: '재원생 관리 · 통계', gate: '탭 미노출' }] },
        ] },
      ],
    },
    {
      id: 'GANGSA-G1', name: '차단 라우트 접근 시도', desc: '권한 잠금 처리',
      nodes: [
        { id: 'GANGSA-G1-01', type: 'action', title: '재원생 관리 / 통계 URL·라우트 직접 진입 시도' },
        { id: 'GANGSA-G1-02', type: 'gate', title: '권한 없음', gate: 'allowed 미포함' },
        { id: 'GANGSA-G1-03', type: 'state', title: '허브로 리다이렉트', state: 'route → hub' },
      ],
    },
    {
      id: 'GANGSA-F5', name: '설명회 운영 (강사)', desc: '원장 F5와 동일 — 전 기능 수행',
      nodes: [
        { id: 'GANGSA-F5-01', type: 'screen', title: 'QR 현황 대시보드', note: '스탯 카드·전체 명단·강사/반 필터 모두 열람. 강사 본인 담당 반 필터로 모니터링 가능.' },
        { id: 'GANGSA-F5-02', type: 'action', title: '즉석 예약 · 수동 체크인 · 입장 취소 · 전환 · 명단 인쇄 · 종료', note: '동작 권한 있음 (→ OWNER-F5 상세 동일).' },
      ],
    },
  ];

  const PARENT_FLOWS = [
    {
      id: 'PARENT-P1', name: '설명회 선택', desc: '모바일 · 로그인 없음',
      nodes: [
        { id: 'PARENT-P1-01', type: 'start', title: 'mobile.html 접속', note: '로그인 없이 바로 예약.' },
        { id: 'PARENT-P1-02', type: 'screen', title: '설명회 목록', note: '제목·일시·장소·잔여석 게이지 + 안내문 있으면 배지.' },
        { id: 'PARENT-P1-03', type: 'decision', title: '잔여석 상태', branches: [
          { cond: '마감 (0석)', nodes: [{ id: 'PARENT-P1-04', type: 'end', title: '카드 비활성 (선택 불가)' }] },
          { cond: '임박 (≤15%)', nodes: [{ id: 'PARENT-P1-05', type: 'screen', title: '경고 배지 표시 → 진행' }] },
          { cond: '여유', nodes: [{ id: 'PARENT-P1-06', type: 'screen', title: '→ 재원생 예약 (P2)' }] },
        ] },
      ],
    },
    {
      id: 'PARENT-P2', name: '재원생 예약 (가족 포함)', desc: '단일·다중(형제)',
      nodes: [
        { id: 'PARENT-P2-01', type: 'screen', title: '재원생 예약 화면', note: '설명회 정보 + 안내문(있으면) 콜아웃.' },
        { id: 'PARENT-P2-02', type: 'action', title: '학부모 연락처 입력 → 조회' },
        { id: 'PARENT-P2-03', type: 'decision', title: '일치 학생?', branches: [
          { cond: '불일치', nodes: [{ id: 'PARENT-P2-04', type: 'screen', title: '에러 안내 → 비재원생 예약 유도 (P3)' }] },
          { cond: '일치', nodes: [
            { id: 'PARENT-P2-05', type: 'action', title: '학생 카드 다중 체크 선택 (최대 3, 형제)' },
            { id: 'PARENT-P2-06', type: 'decision', title: 'attendField?', branches: [{ cond: 'true', nodes: [{ id: 'PARENT-P2-07', type: 'action', title: '자녀당 참석 인원 선택' }] }] },
            { id: 'PARENT-P2-08', type: 'decision', title: '하단 CTA', branches: [
              { cond: '1명', nodes: [{ id: 'PARENT-P2-09', type: 'state', title: '○○ 학생으로 예약', state: '→ reserved', sms: '예약 확정 + QR' }] },
              { cond: 'N명', nodes: [{ id: 'PARENT-P2-10', type: 'state', title: 'N명 예약하기 (각자 QR)', state: '+N Reservation · groupId', sms: '자녀별 개별 확정' }] },
            ] },
            { id: 'PARENT-P2-11', type: 'screen', title: '예약 완료 티켓', note: 'QR·예약자·일시·예약번호 + (가족 시) 자녀별 목록.' },
          ] },
        ] },
      ],
    },
    {
      id: 'PARENT-P3', name: '비재원생 예약',
      nodes: [
        { id: 'PARENT-P3-01', type: 'action', title: "'비재원생 예약하기' 링크" },
        { id: 'PARENT-P3-02', type: 'screen', title: '폼: 이름*·학교·학년·연락처*' },
        { id: 'PARENT-P3-03', type: 'decision', title: 'attendField?', branches: [{ cond: 'true', nodes: [{ id: 'PARENT-P3-04', type: 'action', title: '참석 인원 선택' }] }] },
        { id: 'PARENT-P3-05', type: 'state', title: '예약 생성 (member=false)', state: '→ reserved', sms: '예약 확정 + QR' },
      ],
    },
    {
      id: 'PARENT-P4', name: '예약 조회 · 변경 · 취소', desc: '셀프 관리',
      nodes: [
        { id: 'PARENT-P4-01', type: 'action', title: "목록 하단 '예약 조회 · 변경 · 취소' 링크" },
        { id: 'PARENT-P4-02', type: 'screen', title: '예약 조회 (연락처 + 예약번호)' },
        { id: 'PARENT-P4-03', type: 'decision', title: '일치?', branches: [
          { cond: '불일치', nodes: [{ id: 'PARENT-P4-04', type: 'screen', title: '에러 안내' }] },
          { cond: '일치', nodes: [
            { id: 'PARENT-P4-05', type: 'screen', title: '내 예약 티켓 (상태·이력)' },
            { id: 'PARENT-P4-06', type: 'decision', title: '관리 선택', branches: [
              { cond: '예약 변경', nodes: [
                { id: 'PARENT-P4-07', type: 'screen', title: '회차 선택 시트(잔여석)' },
                { id: 'PARENT-P4-08', type: 'state', title: '설명회 이동 (QR 유지)', state: 'sessionId 이동 · history[]', sms: '변경 확정' },
              ] },
              { cond: '예약 취소', nodes: [
                { id: 'PARENT-P4-09', type: 'decision', title: '취소 확인 (시작 24h 전)' },
                { id: 'PARENT-P4-10', type: 'state', title: '취소', state: '→ cancelled (by parent)', sms: '취소 확인' },
              ] },
            ] },
          ] },
        ] },
      ],
    },
    {
      id: 'PARENT-P5', name: '상담 신청',
      nodes: [
        { id: 'PARENT-P5-01', type: 'screen', title: "예약 완료 화면 '개별 상담 신청'" },
        { id: 'PARENT-P5-02', type: 'screen', title: '슬롯 선택 (강사별 가능 시간)' },
        { id: 'PARENT-P5-03', type: 'state', title: '상담 신청 생성', state: '+CounselBooking', sms: '상담 확정 · 리마인드' },
        { id: 'PARENT-P5-04', type: 'end', title: '신청 완료 → 콘솔 상담 목록 반영 (OWNER-F6)' },
      ],
    },
    {
      id: 'PARENT-P6', name: '만족도 설문',
      nodes: [
        { id: 'PARENT-P6-01', type: 'screen', title: "목록 하단 '만족도 설문' 링크" },
        { id: 'PARENT-P6-02', type: 'action', title: '별점(1~5) + 객관식 3문항 + 주관식 1' },
        { id: 'PARENT-P6-03', type: 'decision', title: '제출 가능?', note: '별점 미선택 시 비활성.', branches: [
          { cond: '가능', nodes: [
            { id: 'PARENT-P6-04', type: 'state', title: '응답 저장', state: '+SurveyResponse' },
            { id: 'PARENT-P6-05', type: 'end', title: '감사 화면' },
          ] },
        ] },
      ],
    },
  ];

  window.NPR_FLOWS = {
    personas: [
      {
        key: 'owner', name: '원장', role: '학원 총괄 · 최고 관리자',
        goal: '설명회 전 과정을 한눈에 관리하고 참석·전환 성과를 확인한다.',
        entry: '로그인(원장) → 허브 8개 모듈 전체',
        scenario: ['설명회 기획·생성(페이지 꾸미기 포함)', '예약·현장 입장 현황 점검', '통계로 참석률·전환율 리뷰', '상담 연계·리마인드·설문 운영 총괄'],
        perms: [{ label: '전체 8모듈', on: true }, { label: '통계', on: true }, { label: '재원생 관리', on: true }],
        flows: OWNER_FLOWS,
      },
      {
        key: 'siljang', name: '실장', role: '운영 실무 총괄 · 원장 대행',
        goal: '원장과 100% 동일 권한으로 일상 운영 전반을 집행한다.',
        entry: '로그인(실장) → 허브 8개 모듈 전체 (원장과 동일)',
        scenario: ['예약 접수·수동예약 등록', '문자 발송·리마인드 운영', '현장 QR 입장·명단 관리', '상담 배정·설문 발송'],
        perms: [{ label: '원장과 동일', on: true }, { label: '전체 8모듈', on: true }, { label: '통계', on: true }],
        note: '실장 권한은 원장과 100% 동일합니다. 아래 플로우는 원장(OWNER-*)과 동일한 흐름을 그대로 따릅니다.',
        flows: OWNER_FLOWS,
      },
      {
        key: 'gangsa', name: '강사', role: '강의 · 현장 운영 지원 (=직원)',
        goal: '현장 입장·예약·문자·상담 등 운영을 지원한다. 전체 명단·통계는 제외.',
        entry: '로그인(강사) → 허브(재원생 관리·통계 잠금)',
        scenario: ['전화예약 접수·상세 관리', '설명회 명단 확인·현장 체크인', 'QR 스캐너로 입장 처리', '상담 안내·문자 발송'],
        perms: [{ label: '설명회·전화·문자·상담·QR', on: true }, { label: '재원생 관리', on: false }, { label: '통계', on: false }],
        note: '강사(=직원)는 재원생 관리(전체 명단)·통계 대시보드만 접근 불가입니다. 그 외 전화예약·문자·설명회 운영·상담·QR 스캐너·프리뷰는 원장과 동일하게 보기+동작 가능 — 아래는 로그인/게이팅과 설명회 운영 델타만 표기하며, 나머지는 OWNER-F3·F4·F6·F8·F9를 그대로 따릅니다.',
        flows: GANGSA_FLOWS,
      },
      {
        key: 'parent', name: '학부모 / 학생', role: '설명회 예약자 (모바일)',
        goal: '자녀 설명회를 예약·관리하고 상담을 신청한다.',
        entry: 'mobile.html — 로그인 없음',
        scenario: ['설명회 선택·예약(가족 동시 예약 포함)', '예약 조회·회차 변경·취소', '입장 완료 후 개별 상담 신청', '종료 후 만족도 설문 응답'],
        perms: [{ label: '모바일 예약', on: true }, { label: '콘솔 접근', on: false }, { label: '로그인', on: false }],
        flows: PARENT_FLOWS,
      },
    ],
  };
})();
